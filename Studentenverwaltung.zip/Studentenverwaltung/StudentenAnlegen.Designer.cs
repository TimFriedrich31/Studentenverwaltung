﻿namespace Studentenverwaltung
{
    partial class StudentenAnlegen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ComboBoxPartnerhochschule = new System.Windows.Forms.ComboBox();
            this.ComboBoxStudiengang = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.TxtBoxStudententyp = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.Semester = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TxtBoxEmail = new System.Windows.Forms.TextBox();
            this.TxtBoxTelefon = new System.Windows.Forms.TextBox();
            this.TxtBoxWohnort = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtBoxPLZ = new System.Windows.Forms.TextBox();
            this.TxtBoxHausnummer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtBoxStrasse = new System.Windows.Forms.TextBox();
            this.TxtBoxNationalität = new System.Windows.Forms.TextBox();
            this.TxtBoxGeburtsort = new System.Windows.Forms.TextBox();
            this.TxtBoxGeburtsdatum = new System.Windows.Forms.TextBox();
            this.TxtBoxVorname = new System.Windows.Forms.TextBox();
            this.TxtBoxNachname = new System.Windows.Forms.TextBox();
            this.CmdStudentenAnlegen = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.TxtBoxEmailStudiengangsleitung = new System.Windows.Forms.TextBox();
            this.TxtBoxTelefonStudiengangsleitung = new System.Windows.Forms.TextBox();
            this.TxtBoxStudiengangsleiter = new System.Windows.Forms.TextBox();
            this.TxtBoxStudiengangTblStudiengang = new System.Windows.Forms.TextBox();
            this.CmdStudentenAnlegenTblStudiengang = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.CmdPartnerhochschuleAnlegen = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.TxtBoxKontaktperson = new System.Windows.Forms.TextBox();
            this.TxtBoxLand = new System.Windows.Forms.TextBox();
            this.TxtBoxOrt = new System.Windows.Forms.TextBox();
            this.TxtBoxPartnerhochschuleTblAuslandssemester = new System.Windows.Forms.TextBox();
            this.DateTimePickerStudienbeginn = new System.Windows.Forms.DateTimePicker();
            this.DateTimePickerStudienende = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.LblSemester = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.LblSemester);
            this.groupBox1.Controls.Add(this.DateTimePickerStudienende);
            this.groupBox1.Controls.Add(this.ComboBoxPartnerhochschule);
            this.groupBox1.Controls.Add(this.DateTimePickerStudienbeginn);
            this.groupBox1.Controls.Add(this.ComboBoxStudiengang);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.TxtBoxStudententyp);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.Semester);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.TxtBoxEmail);
            this.groupBox1.Controls.Add(this.TxtBoxTelefon);
            this.groupBox1.Controls.Add(this.TxtBoxWohnort);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.TxtBoxPLZ);
            this.groupBox1.Controls.Add(this.TxtBoxHausnummer);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.TxtBoxStrasse);
            this.groupBox1.Controls.Add(this.TxtBoxNationalität);
            this.groupBox1.Controls.Add(this.TxtBoxGeburtsort);
            this.groupBox1.Controls.Add(this.TxtBoxGeburtsdatum);
            this.groupBox1.Controls.Add(this.TxtBoxVorname);
            this.groupBox1.Controls.Add(this.TxtBoxNachname);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1983, 123);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Studenten anlegen";
            // 
            // ComboBoxPartnerhochschule
            // 
            this.ComboBoxPartnerhochschule.FormattingEnabled = true;
            this.ComboBoxPartnerhochschule.Location = new System.Drawing.Point(821, 73);
            this.ComboBoxPartnerhochschule.Name = "ComboBoxPartnerhochschule";
            this.ComboBoxPartnerhochschule.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxPartnerhochschule.TabIndex = 2;
            // 
            // ComboBoxStudiengang
            // 
            this.ComboBoxStudiengang.FormattingEnabled = true;
            this.ComboBoxStudiengang.Location = new System.Drawing.Point(218, 73);
            this.ComboBoxStudiengang.Name = "ComboBoxStudiengang";
            this.ComboBoxStudiengang.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxStudiengang.TabIndex = 3;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(731, 57);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 13);
            this.label17.TabIndex = 42;
            this.label17.Text = "Studententyp";
            // 
            // TxtBoxStudententyp
            // 
            this.TxtBoxStudententyp.Location = new System.Drawing.Point(715, 73);
            this.TxtBoxStudententyp.Name = "TxtBoxStudententyp";
            this.TxtBoxStudententyp.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudententyp.TabIndex = 41;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(607, 57);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 13);
            this.label16.TabIndex = 40;
            this.label16.Text = "Studienende";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(466, 57);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 13);
            this.label15.TabIndex = 38;
            this.label15.Text = "Studienbeginn";
            // 
            // Semester
            // 
            this.Semester.AutoSize = true;
            this.Semester.Location = new System.Drawing.Point(360, 57);
            this.Semester.Name = "Semester";
            this.Semester.Size = new System.Drawing.Size(51, 13);
            this.Semester.TabIndex = 36;
            this.Semester.Text = "Semester";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(863, 57);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 13);
            this.label14.TabIndex = 29;
            this.label14.Text = "Ausland";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(843, 44);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Partnerhochschule ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(251, 57);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Studiengang";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1824, 57);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "E-Mail";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1717, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Telefon";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1610, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Wohnort";
            // 
            // TxtBoxEmail
            // 
            this.TxtBoxEmail.Location = new System.Drawing.Point(1796, 73);
            this.TxtBoxEmail.Name = "TxtBoxEmail";
            this.TxtBoxEmail.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxEmail.TabIndex = 18;
            // 
            // TxtBoxTelefon
            // 
            this.TxtBoxTelefon.Location = new System.Drawing.Point(1690, 73);
            this.TxtBoxTelefon.Name = "TxtBoxTelefon";
            this.TxtBoxTelefon.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxTelefon.TabIndex = 17;
            // 
            // TxtBoxWohnort
            // 
            this.TxtBoxWohnort.Location = new System.Drawing.Point(1584, 73);
            this.TxtBoxWohnort.Name = "TxtBoxWohnort";
            this.TxtBoxWohnort.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxWohnort.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1514, 57);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "PLZ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1388, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Hausnummer";
            // 
            // TxtBoxPLZ
            // 
            this.TxtBoxPLZ.Location = new System.Drawing.Point(1478, 73);
            this.TxtBoxPLZ.Name = "TxtBoxPLZ";
            this.TxtBoxPLZ.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxPLZ.TabIndex = 13;
            // 
            // TxtBoxHausnummer
            // 
            this.TxtBoxHausnummer.Location = new System.Drawing.Point(1372, 73);
            this.TxtBoxHausnummer.Name = "TxtBoxHausnummer";
            this.TxtBoxHausnummer.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxHausnummer.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1289, 57);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Strasse";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1182, 57);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nationalität";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1078, 57);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Geburtsort";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(963, 57);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Geburtsdatum";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(137, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Vorname";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nachname";
            // 
            // TxtBoxStrasse
            // 
            this.TxtBoxStrasse.Location = new System.Drawing.Point(1266, 73);
            this.TxtBoxStrasse.Name = "TxtBoxStrasse";
            this.TxtBoxStrasse.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStrasse.TabIndex = 5;
            // 
            // TxtBoxNationalität
            // 
            this.TxtBoxNationalität.Location = new System.Drawing.Point(1160, 73);
            this.TxtBoxNationalität.Name = "TxtBoxNationalität";
            this.TxtBoxNationalität.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxNationalität.TabIndex = 4;
            // 
            // TxtBoxGeburtsort
            // 
            this.TxtBoxGeburtsort.Location = new System.Drawing.Point(1054, 73);
            this.TxtBoxGeburtsort.Name = "TxtBoxGeburtsort";
            this.TxtBoxGeburtsort.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxGeburtsort.TabIndex = 3;
            // 
            // TxtBoxGeburtsdatum
            // 
            this.TxtBoxGeburtsdatum.Location = new System.Drawing.Point(948, 73);
            this.TxtBoxGeburtsdatum.Name = "TxtBoxGeburtsdatum";
            this.TxtBoxGeburtsdatum.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxGeburtsdatum.TabIndex = 2;
            // 
            // TxtBoxVorname
            // 
            this.TxtBoxVorname.Location = new System.Drawing.Point(112, 73);
            this.TxtBoxVorname.Name = "TxtBoxVorname";
            this.TxtBoxVorname.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxVorname.TabIndex = 1;
            // 
            // TxtBoxNachname
            // 
            this.TxtBoxNachname.Location = new System.Drawing.Point(6, 73);
            this.TxtBoxNachname.Name = "TxtBoxNachname";
            this.TxtBoxNachname.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxNachname.TabIndex = 0;
            // 
            // CmdStudentenAnlegen
            // 
            this.CmdStudentenAnlegen.Location = new System.Drawing.Point(6, 135);
            this.CmdStudentenAnlegen.Name = "CmdStudentenAnlegen";
            this.CmdStudentenAnlegen.Size = new System.Drawing.Size(206, 23);
            this.CmdStudentenAnlegen.TabIndex = 1;
            this.CmdStudentenAnlegen.Text = "Studenten anlegen";
            this.CmdStudentenAnlegen.UseVisualStyleBackColor = true;
            this.CmdStudentenAnlegen.Click += new System.EventHandler(this.CmdStudentenAnlegen_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(2003, 243);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.CmdStudentenAnlegen);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1995, 217);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tabelle Studenten";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox2);
            this.tabPage2.Controls.Add(this.CmdStudentenAnlegenTblStudiengang);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1995, 217);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tabelle Studiengang";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label23);
            this.groupBox2.Controls.Add(this.label22);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.TxtBoxEmailStudiengangsleitung);
            this.groupBox2.Controls.Add(this.TxtBoxTelefonStudiengangsleitung);
            this.groupBox2.Controls.Add(this.TxtBoxStudiengangsleiter);
            this.groupBox2.Controls.Add(this.TxtBoxStudiengangTblStudiengang);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(461, 103);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Studiengang anlegen";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(328, 27);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(103, 13);
            this.label23.TabIndex = 9;
            this.label23.Text = "Studiengangsleitung";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(362, 12);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 13);
            this.label22.TabIndex = 8;
            this.label22.Text = "Email";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(222, 27);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(103, 13);
            this.label21.TabIndex = 7;
            this.label21.Text = "Studiengangsleitung";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(253, 12);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(43, 13);
            this.label20.TabIndex = 6;
            this.label20.Text = "Telefon";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(122, 27);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(94, 13);
            this.label19.TabIndex = 5;
            this.label19.Text = "Studiengangsleiter";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(28, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 13);
            this.label18.TabIndex = 4;
            this.label18.Text = "Studiengang";
            // 
            // TxtBoxEmailStudiengangsleitung
            // 
            this.TxtBoxEmailStudiengangsleitung.Location = new System.Drawing.Point(328, 43);
            this.TxtBoxEmailStudiengangsleitung.Name = "TxtBoxEmailStudiengangsleitung";
            this.TxtBoxEmailStudiengangsleitung.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxEmailStudiengangsleitung.TabIndex = 3;
            // 
            // TxtBoxTelefonStudiengangsleitung
            // 
            this.TxtBoxTelefonStudiengangsleitung.Location = new System.Drawing.Point(222, 43);
            this.TxtBoxTelefonStudiengangsleitung.Name = "TxtBoxTelefonStudiengangsleitung";
            this.TxtBoxTelefonStudiengangsleitung.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxTelefonStudiengangsleitung.TabIndex = 2;
            // 
            // TxtBoxStudiengangsleiter
            // 
            this.TxtBoxStudiengangsleiter.Location = new System.Drawing.Point(116, 43);
            this.TxtBoxStudiengangsleiter.Name = "TxtBoxStudiengangsleiter";
            this.TxtBoxStudiengangsleiter.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudiengangsleiter.TabIndex = 1;
            // 
            // TxtBoxStudiengangTblStudiengang
            // 
            this.TxtBoxStudiengangTblStudiengang.Location = new System.Drawing.Point(10, 43);
            this.TxtBoxStudiengangTblStudiengang.Name = "TxtBoxStudiengangTblStudiengang";
            this.TxtBoxStudiengangTblStudiengang.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudiengangTblStudiengang.TabIndex = 0;
            // 
            // CmdStudentenAnlegenTblStudiengang
            // 
            this.CmdStudentenAnlegenTblStudiengang.Location = new System.Drawing.Point(6, 115);
            this.CmdStudentenAnlegenTblStudiengang.Name = "CmdStudentenAnlegenTblStudiengang";
            this.CmdStudentenAnlegenTblStudiengang.Size = new System.Drawing.Size(159, 23);
            this.CmdStudentenAnlegenTblStudiengang.TabIndex = 10;
            this.CmdStudentenAnlegenTblStudiengang.Text = "Studiengang anlegen";
            this.CmdStudentenAnlegenTblStudiengang.UseVisualStyleBackColor = true;
            this.CmdStudentenAnlegenTblStudiengang.Click += new System.EventHandler(this.CmdStudentenAnlegenTblStudiengang_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.CmdPartnerhochschuleAnlegen);
            this.tabPage3.Controls.Add(this.groupBox3);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1922, 217);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Tabelle Auslandssemester";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // CmdPartnerhochschuleAnlegen
            // 
            this.CmdPartnerhochschuleAnlegen.Location = new System.Drawing.Point(6, 115);
            this.CmdPartnerhochschuleAnlegen.Name = "CmdPartnerhochschuleAnlegen";
            this.CmdPartnerhochschuleAnlegen.Size = new System.Drawing.Size(159, 23);
            this.CmdPartnerhochschuleAnlegen.TabIndex = 13;
            this.CmdPartnerhochschuleAnlegen.Text = "Partnerhochschule anlegen";
            this.CmdPartnerhochschuleAnlegen.UseVisualStyleBackColor = true;
            this.CmdPartnerhochschuleAnlegen.Click += new System.EventHandler(this.CmdPartnerhochschuleAnlegen_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.label28);
            this.groupBox3.Controls.Add(this.label29);
            this.groupBox3.Controls.Add(this.TxtBoxKontaktperson);
            this.groupBox3.Controls.Add(this.TxtBoxLand);
            this.groupBox3.Controls.Add(this.TxtBoxOrt);
            this.groupBox3.Controls.Add(this.TxtBoxPartnerhochschuleTblAuslandssemester);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(461, 103);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Partnerhochschule anlegen";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(339, 27);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 13);
            this.label24.TabIndex = 9;
            this.label24.Text = "Kontaktperson";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(253, 27);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(31, 13);
            this.label26.TabIndex = 7;
            this.label26.Text = "Land";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(151, 27);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(21, 13);
            this.label28.TabIndex = 5;
            this.label28.Text = "Ort";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(28, 27);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(64, 13);
            this.label29.TabIndex = 4;
            this.label29.Text = "Hochschule";
            // 
            // TxtBoxKontaktperson
            // 
            this.TxtBoxKontaktperson.Location = new System.Drawing.Point(328, 43);
            this.TxtBoxKontaktperson.Name = "TxtBoxKontaktperson";
            this.TxtBoxKontaktperson.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxKontaktperson.TabIndex = 3;
            // 
            // TxtBoxLand
            // 
            this.TxtBoxLand.Location = new System.Drawing.Point(222, 43);
            this.TxtBoxLand.Name = "TxtBoxLand";
            this.TxtBoxLand.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxLand.TabIndex = 2;
            // 
            // TxtBoxOrt
            // 
            this.TxtBoxOrt.Location = new System.Drawing.Point(116, 43);
            this.TxtBoxOrt.Name = "TxtBoxOrt";
            this.TxtBoxOrt.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxOrt.TabIndex = 1;
            // 
            // TxtBoxPartnerhochschuleTblAuslandssemester
            // 
            this.TxtBoxPartnerhochschuleTblAuslandssemester.Location = new System.Drawing.Point(10, 43);
            this.TxtBoxPartnerhochschuleTblAuslandssemester.Name = "TxtBoxPartnerhochschuleTblAuslandssemester";
            this.TxtBoxPartnerhochschuleTblAuslandssemester.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxPartnerhochschuleTblAuslandssemester.TabIndex = 0;
            // 
            // DateTimePickerStudienbeginn
            // 
            this.DateTimePickerStudienbeginn.Location = new System.Drawing.Point(435, 73);
            this.DateTimePickerStudienbeginn.Name = "DateTimePickerStudienbeginn";
            this.DateTimePickerStudienbeginn.Size = new System.Drawing.Size(134, 20);
            this.DateTimePickerStudienbeginn.TabIndex = 2;
            this.DateTimePickerStudienbeginn.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // DateTimePickerStudienende
            // 
            this.DateTimePickerStudienende.Location = new System.Drawing.Point(575, 73);
            this.DateTimePickerStudienende.Name = "DateTimePickerStudienende";
            this.DateTimePickerStudienende.Size = new System.Drawing.Size(134, 20);
            this.DateTimePickerStudienende.TabIndex = 3;
            this.DateTimePickerStudienende.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(385, 272);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 3;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(491, 272);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 4;
            // 
            // LblSemester
            // 
            this.LblSemester.AutoSize = true;
            this.LblSemester.Location = new System.Drawing.Point(379, 76);
            this.LblSemester.Name = "LblSemester";
            this.LblSemester.Size = new System.Drawing.Size(9, 13);
            this.LblSemester.TabIndex = 43;
            this.LblSemester.Text = "l";
            this.LblSemester.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(681, 272);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 5;
            this.textBox3.Visible = false;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(787, 272);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 6;
            this.textBox4.Visible = false;
            // 
            // StudentenAnlegen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2015, 450);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tabControl1);
            this.Name = "StudentenAnlegen";
            this.Text = "Studenten anlegen";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TxtBoxEmail;
        private System.Windows.Forms.TextBox TxtBoxTelefon;
        private System.Windows.Forms.TextBox TxtBoxWohnort;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TxtBoxPLZ;
        private System.Windows.Forms.TextBox TxtBoxHausnummer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtBoxStrasse;
        private System.Windows.Forms.TextBox TxtBoxNationalität;
        private System.Windows.Forms.TextBox TxtBoxGeburtsort;
        private System.Windows.Forms.TextBox TxtBoxGeburtsdatum;
        private System.Windows.Forms.TextBox TxtBoxVorname;
        public System.Windows.Forms.TextBox TxtBoxNachname;
        public System.Windows.Forms.Button CmdStudentenAnlegen;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox TxtBoxStudententyp;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label Semester;
        private System.Windows.Forms.ComboBox ComboBoxPartnerhochschule;
        private System.Windows.Forms.ComboBox ComboBoxStudiengang;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox TxtBoxEmailStudiengangsleitung;
        private System.Windows.Forms.TextBox TxtBoxTelefonStudiengangsleitung;
        private System.Windows.Forms.TextBox TxtBoxStudiengangsleiter;
        private System.Windows.Forms.TextBox TxtBoxStudiengangTblStudiengang;
        private System.Windows.Forms.Button CmdStudentenAnlegenTblStudiengang;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button CmdPartnerhochschuleAnlegen;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox TxtBoxKontaktperson;
        private System.Windows.Forms.TextBox TxtBoxLand;
        private System.Windows.Forms.TextBox TxtBoxOrt;
        private System.Windows.Forms.TextBox TxtBoxPartnerhochschuleTblAuslandssemester;
        private System.Windows.Forms.DateTimePicker DateTimePickerStudienende;
        private System.Windows.Forms.DateTimePicker DateTimePickerStudienbeginn;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label LblSemester;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
    }
}