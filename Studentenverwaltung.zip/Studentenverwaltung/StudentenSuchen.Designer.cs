﻿namespace Studentenverwaltung
{
    partial class StudentenSuchen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label28 = new System.Windows.Forms.Label();
            this.TxtBoxMatrikelNr = new System.Windows.Forms.TextBox();
            this.ComboBoxPartnerhochschule = new System.Windows.Forms.ComboBox();
            this.ComboBoxStudiengang = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.TxtBoxStudententyp = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.TxtBoxStudienende = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.TxtBoxStudienbeginn = new System.Windows.Forms.TextBox();
            this.Semester = new System.Windows.Forms.Label();
            this.TxtBoxSemester = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TxtBoxEmail = new System.Windows.Forms.TextBox();
            this.TxtBoxTelefon = new System.Windows.Forms.TextBox();
            this.TxtBoxWohnort = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtBoxPLZ = new System.Windows.Forms.TextBox();
            this.TxtBoxHausnummer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtBoxStrasse = new System.Windows.Forms.TextBox();
            this.TxtBoxNationalität = new System.Windows.Forms.TextBox();
            this.TxtBoxGeburtsort = new System.Windows.Forms.TextBox();
            this.TxtBoxGeburtsdatum = new System.Windows.Forms.TextBox();
            this.TxtBoxVorname = new System.Windows.Forms.TextBox();
            this.TxtBoxNachname = new System.Windows.Forms.TextBox();
            this.CmdStudentenSuchenTabelleStudenten = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.CmdStudiengangSuchen = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ComboBoxStudiengangTblStudiengang = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.TxtBoxEmailStudiengangsleitung = new System.Windows.Forms.TextBox();
            this.TxtBoxTelefonStudiengangsleitung = new System.Windows.Forms.TextBox();
            this.TxtBoxStudiengangsleiter = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.CmdPartnerhochschuleSuchen = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ComboBoxPartnerhochschuleTblAuslandssemester = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.TxtBoxKontaktperson = new System.Windows.Forms.TextBox();
            this.TxtBoxLand = new System.Windows.Forms.TextBox();
            this.TxtBoxOrt = new System.Windows.Forms.TextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.CmdVorlesungen = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Matrikelnummer = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.TxtBoxMatrikelNr);
            this.groupBox1.Controls.Add(this.ComboBoxPartnerhochschule);
            this.groupBox1.Controls.Add(this.ComboBoxStudiengang);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.TxtBoxStudententyp);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.TxtBoxStudienende);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.TxtBoxStudienbeginn);
            this.groupBox1.Controls.Add(this.Semester);
            this.groupBox1.Controls.Add(this.TxtBoxSemester);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.TxtBoxEmail);
            this.groupBox1.Controls.Add(this.TxtBoxTelefon);
            this.groupBox1.Controls.Add(this.TxtBoxWohnort);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.TxtBoxPLZ);
            this.groupBox1.Controls.Add(this.TxtBoxHausnummer);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.TxtBoxStrasse);
            this.groupBox1.Controls.Add(this.TxtBoxNationalität);
            this.groupBox1.Controls.Add(this.TxtBoxGeburtsort);
            this.groupBox1.Controls.Add(this.TxtBoxGeburtsdatum);
            this.groupBox1.Controls.Add(this.TxtBoxVorname);
            this.groupBox1.Controls.Add(this.TxtBoxNachname);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1975, 123);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Studenten suchen";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(16, 53);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(81, 13);
            this.label28.TabIndex = 37;
            this.label28.Text = "Matrikelnummer";
            // 
            // TxtBoxMatrikelNr
            // 
            this.TxtBoxMatrikelNr.Location = new System.Drawing.Point(6, 69);
            this.TxtBoxMatrikelNr.Name = "TxtBoxMatrikelNr";
            this.TxtBoxMatrikelNr.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxMatrikelNr.TabIndex = 3;
            // 
            // ComboBoxPartnerhochschule
            // 
            this.ComboBoxPartnerhochschule.FormattingEnabled = true;
            this.ComboBoxPartnerhochschule.Location = new System.Drawing.Point(875, 69);
            this.ComboBoxPartnerhochschule.Name = "ComboBoxPartnerhochschule";
            this.ComboBoxPartnerhochschule.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxPartnerhochschule.TabIndex = 36;
            // 
            // ComboBoxStudiengang
            // 
            this.ComboBoxStudiengang.FormattingEnabled = true;
            this.ComboBoxStudiengang.Location = new System.Drawing.Point(324, 69);
            this.ComboBoxStudiengang.Name = "ComboBoxStudiengang";
            this.ComboBoxStudiengang.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxStudiengang.TabIndex = 35;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(785, 53);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 13);
            this.label17.TabIndex = 34;
            this.label17.Text = "Studententyp";
            // 
            // TxtBoxStudententyp
            // 
            this.TxtBoxStudententyp.Location = new System.Drawing.Point(769, 69);
            this.TxtBoxStudententyp.Name = "TxtBoxStudententyp";
            this.TxtBoxStudententyp.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudententyp.TabIndex = 33;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(680, 53);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 13);
            this.label16.TabIndex = 32;
            this.label16.Text = "Studienende";
            // 
            // TxtBoxStudienende
            // 
            this.TxtBoxStudienende.Location = new System.Drawing.Point(663, 69);
            this.TxtBoxStudienende.Name = "TxtBoxStudienende";
            this.TxtBoxStudienende.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudienende.TabIndex = 31;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(569, 53);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 13);
            this.label15.TabIndex = 30;
            this.label15.Text = "Studienbeginn";
            // 
            // TxtBoxStudienbeginn
            // 
            this.TxtBoxStudienbeginn.Location = new System.Drawing.Point(557, 69);
            this.TxtBoxStudienbeginn.Name = "TxtBoxStudienbeginn";
            this.TxtBoxStudienbeginn.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudienbeginn.TabIndex = 29;
            // 
            // Semester
            // 
            this.Semester.AutoSize = true;
            this.Semester.Location = new System.Drawing.Point(478, 53);
            this.Semester.Name = "Semester";
            this.Semester.Size = new System.Drawing.Size(51, 13);
            this.Semester.TabIndex = 28;
            this.Semester.Text = "Semester";
            // 
            // TxtBoxSemester
            // 
            this.TxtBoxSemester.Location = new System.Drawing.Point(451, 69);
            this.TxtBoxSemester.Name = "TxtBoxSemester";
            this.TxtBoxSemester.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxSemester.TabIndex = 27;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(912, 53);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 13);
            this.label14.TabIndex = 26;
            this.label14.Text = "Ausland";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(886, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 25;
            this.label13.Text = "Partnerhochschule ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(352, 53);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Studiengang";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1878, 53);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "E-Mail";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1771, 53);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Telefon";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1664, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Wohnort";
            // 
            // TxtBoxEmail
            // 
            this.TxtBoxEmail.Location = new System.Drawing.Point(1850, 69);
            this.TxtBoxEmail.Name = "TxtBoxEmail";
            this.TxtBoxEmail.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxEmail.TabIndex = 18;
            // 
            // TxtBoxTelefon
            // 
            this.TxtBoxTelefon.Location = new System.Drawing.Point(1744, 69);
            this.TxtBoxTelefon.Name = "TxtBoxTelefon";
            this.TxtBoxTelefon.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxTelefon.TabIndex = 17;
            // 
            // TxtBoxWohnort
            // 
            this.TxtBoxWohnort.Location = new System.Drawing.Point(1638, 69);
            this.TxtBoxWohnort.Name = "TxtBoxWohnort";
            this.TxtBoxWohnort.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxWohnort.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1568, 53);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "PLZ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1442, 53);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Hausnummer";
            // 
            // TxtBoxPLZ
            // 
            this.TxtBoxPLZ.Location = new System.Drawing.Point(1532, 69);
            this.TxtBoxPLZ.Name = "TxtBoxPLZ";
            this.TxtBoxPLZ.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxPLZ.TabIndex = 13;
            // 
            // TxtBoxHausnummer
            // 
            this.TxtBoxHausnummer.Location = new System.Drawing.Point(1426, 69);
            this.TxtBoxHausnummer.Name = "TxtBoxHausnummer";
            this.TxtBoxHausnummer.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxHausnummer.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1343, 53);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Strasse";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1236, 53);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nationalität";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1132, 53);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Geburtsort";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1017, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Geburtsdatum";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(243, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Vorname";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(129, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nachname";
            // 
            // TxtBoxStrasse
            // 
            this.TxtBoxStrasse.Location = new System.Drawing.Point(1320, 69);
            this.TxtBoxStrasse.Name = "TxtBoxStrasse";
            this.TxtBoxStrasse.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStrasse.TabIndex = 5;
            // 
            // TxtBoxNationalität
            // 
            this.TxtBoxNationalität.Location = new System.Drawing.Point(1214, 69);
            this.TxtBoxNationalität.Name = "TxtBoxNationalität";
            this.TxtBoxNationalität.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxNationalität.TabIndex = 4;
            // 
            // TxtBoxGeburtsort
            // 
            this.TxtBoxGeburtsort.Location = new System.Drawing.Point(1108, 69);
            this.TxtBoxGeburtsort.Name = "TxtBoxGeburtsort";
            this.TxtBoxGeburtsort.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxGeburtsort.TabIndex = 3;
            // 
            // TxtBoxGeburtsdatum
            // 
            this.TxtBoxGeburtsdatum.Location = new System.Drawing.Point(1002, 69);
            this.TxtBoxGeburtsdatum.Name = "TxtBoxGeburtsdatum";
            this.TxtBoxGeburtsdatum.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxGeburtsdatum.TabIndex = 2;
            // 
            // TxtBoxVorname
            // 
            this.TxtBoxVorname.Location = new System.Drawing.Point(218, 69);
            this.TxtBoxVorname.Name = "TxtBoxVorname";
            this.TxtBoxVorname.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxVorname.TabIndex = 1;
            // 
            // TxtBoxNachname
            // 
            this.TxtBoxNachname.Location = new System.Drawing.Point(112, 69);
            this.TxtBoxNachname.Name = "TxtBoxNachname";
            this.TxtBoxNachname.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxNachname.TabIndex = 0;
            // 
            // CmdStudentenSuchenTabelleStudenten
            // 
            this.CmdStudentenSuchenTabelleStudenten.Location = new System.Drawing.Point(6, 135);
            this.CmdStudentenSuchenTabelleStudenten.Name = "CmdStudentenSuchenTabelleStudenten";
            this.CmdStudentenSuchenTabelleStudenten.Size = new System.Drawing.Size(212, 23);
            this.CmdStudentenSuchenTabelleStudenten.TabIndex = 2;
            this.CmdStudentenSuchenTabelleStudenten.Text = "Studenten suchen";
            this.CmdStudentenSuchenTabelleStudenten.UseVisualStyleBackColor = true;
            this.CmdStudentenSuchenTabelleStudenten.Click += new System.EventHandler(this.CmdStudentenSuchen_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(18, 351);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1816, 286);
            this.dataGridView1.TabIndex = 3;
            this.dataGridView1.Visible = false;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(11, 9);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1995, 223);
            this.tabControl1.TabIndex = 4;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.CmdStudentenSuchenTabelleStudenten);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1987, 197);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tabelle Studenten";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.CmdStudiengangSuchen);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1987, 197);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tabelle Studiengang";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // CmdStudiengangSuchen
            // 
            this.CmdStudiengangSuchen.Location = new System.Drawing.Point(6, 126);
            this.CmdStudiengangSuchen.Name = "CmdStudiengangSuchen";
            this.CmdStudiengangSuchen.Size = new System.Drawing.Size(196, 23);
            this.CmdStudiengangSuchen.TabIndex = 16;
            this.CmdStudiengangSuchen.Text = "Studiengang suchen";
            this.CmdStudiengangSuchen.UseVisualStyleBackColor = true;
            this.CmdStudiengangSuchen.Click += new System.EventHandler(this.CmdStudiengangSuchen_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ComboBoxStudiengangTblStudiengang);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.TxtBoxEmailStudiengangsleitung);
            this.groupBox3.Controls.Add(this.TxtBoxTelefonStudiengangsleitung);
            this.groupBox3.Controls.Add(this.TxtBoxStudiengangsleiter);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.label22);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(664, 114);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Studiengang suchen";
            // 
            // ComboBoxStudiengangTblStudiengang
            // 
            this.ComboBoxStudiengangTblStudiengang.FormattingEnabled = true;
            this.ComboBoxStudiengangTblStudiengang.Location = new System.Drawing.Point(6, 52);
            this.ComboBoxStudiengangTblStudiengang.Name = "ComboBoxStudiengangTblStudiengang";
            this.ComboBoxStudiengangTblStudiengang.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxStudiengangTblStudiengang.TabIndex = 10;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(342, 37);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 13);
            this.label27.TabIndex = 9;
            this.label27.Text = "Studiengangsleitung";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(239, 37);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(103, 13);
            this.label26.TabIndex = 8;
            this.label26.Text = "Studiengangsleitung";
            // 
            // TxtBoxEmailStudiengangsleitung
            // 
            this.TxtBoxEmailStudiengangsleitung.Location = new System.Drawing.Point(345, 53);
            this.TxtBoxEmailStudiengangsleitung.Name = "TxtBoxEmailStudiengangsleitung";
            this.TxtBoxEmailStudiengangsleitung.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxEmailStudiengangsleitung.TabIndex = 7;
            // 
            // TxtBoxTelefonStudiengangsleitung
            // 
            this.TxtBoxTelefonStudiengangsleitung.Location = new System.Drawing.Point(239, 53);
            this.TxtBoxTelefonStudiengangsleitung.Name = "TxtBoxTelefonStudiengangsleitung";
            this.TxtBoxTelefonStudiengangsleitung.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxTelefonStudiengangsleitung.TabIndex = 6;
            // 
            // TxtBoxStudiengangsleiter
            // 
            this.TxtBoxStudiengangsleiter.Location = new System.Drawing.Point(133, 53);
            this.TxtBoxStudiengangsleiter.Name = "TxtBoxStudiengangsleiter";
            this.TxtBoxStudiengangsleiter.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudiengangsleiter.TabIndex = 5;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(378, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(32, 13);
            this.label25.TabIndex = 3;
            this.label25.Text = "Email";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(266, 24);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 13);
            this.label24.TabIndex = 2;
            this.label24.Text = "Telefon";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(139, 37);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(94, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "Studiengangsleiter";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(35, 37);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(67, 13);
            this.label22.TabIndex = 0;
            this.label22.Text = "Studiengang";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.CmdPartnerhochschuleSuchen);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1987, 197);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Tabelle Auslandssemester";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // CmdPartnerhochschuleSuchen
            // 
            this.CmdPartnerhochschuleSuchen.Location = new System.Drawing.Point(6, 115);
            this.CmdPartnerhochschuleSuchen.Name = "CmdPartnerhochschuleSuchen";
            this.CmdPartnerhochschuleSuchen.Size = new System.Drawing.Size(184, 23);
            this.CmdPartnerhochschuleSuchen.TabIndex = 15;
            this.CmdPartnerhochschuleSuchen.Text = "Partnerhochschule suchen";
            this.CmdPartnerhochschuleSuchen.UseVisualStyleBackColor = true;
            this.CmdPartnerhochschuleSuchen.Click += new System.EventHandler(this.CmdPartnerhochschuleSuchen_Click_1);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ComboBoxPartnerhochschuleTblAuslandssemester);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.label21);
            this.groupBox2.Controls.Add(this.TxtBoxKontaktperson);
            this.groupBox2.Controls.Add(this.TxtBoxLand);
            this.groupBox2.Controls.Add(this.TxtBoxOrt);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(508, 103);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Partnerhochschule suchen ";
            // 
            // ComboBoxPartnerhochschuleTblAuslandssemester
            // 
            this.ComboBoxPartnerhochschuleTblAuslandssemester.FormattingEnabled = true;
            this.ComboBoxPartnerhochschuleTblAuslandssemester.Location = new System.Drawing.Point(6, 43);
            this.ComboBoxPartnerhochschuleTblAuslandssemester.Name = "ComboBoxPartnerhochschuleTblAuslandssemester";
            this.ComboBoxPartnerhochschuleTblAuslandssemester.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxPartnerhochschuleTblAuslandssemester.TabIndex = 16;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(356, 27);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(76, 13);
            this.label18.TabIndex = 9;
            this.label18.Text = "Kontaktperson";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(270, 27);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(31, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "Land";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(168, 27);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(21, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "Ort";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(28, 27);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 13);
            this.label21.TabIndex = 4;
            this.label21.Text = "Hochschule";
            // 
            // TxtBoxKontaktperson
            // 
            this.TxtBoxKontaktperson.Location = new System.Drawing.Point(345, 43);
            this.TxtBoxKontaktperson.Name = "TxtBoxKontaktperson";
            this.TxtBoxKontaktperson.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxKontaktperson.TabIndex = 3;
            // 
            // TxtBoxLand
            // 
            this.TxtBoxLand.Location = new System.Drawing.Point(239, 43);
            this.TxtBoxLand.Name = "TxtBoxLand";
            this.TxtBoxLand.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxLand.TabIndex = 2;
            // 
            // TxtBoxOrt
            // 
            this.TxtBoxOrt.Location = new System.Drawing.Point(133, 43);
            this.TxtBoxOrt.Name = "TxtBoxOrt";
            this.TxtBoxOrt.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxOrt.TabIndex = 1;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.Matrikelnummer);
            this.tabPage4.Controls.Add(this.textBox1);
            this.tabPage4.Controls.Add(this.CmdVorlesungen);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1987, 197);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Tabelle Vorlesungen";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // CmdVorlesungen
            // 
            this.CmdVorlesungen.Location = new System.Drawing.Point(18, 84);
            this.CmdVorlesungen.Name = "CmdVorlesungen";
            this.CmdVorlesungen.Size = new System.Drawing.Size(128, 23);
            this.CmdVorlesungen.TabIndex = 10;
            this.CmdVorlesungen.Text = "Vorlesungen suchen";
            this.CmdVorlesungen.UseVisualStyleBackColor = true;
            this.CmdVorlesungen.Click += new System.EventHandler(this.CmdVorlesungen_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(6, 46);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(156, 20);
            this.textBox1.TabIndex = 12;
            // 
            // Matrikelnummer
            // 
            this.Matrikelnummer.AutoSize = true;
            this.Matrikelnummer.Location = new System.Drawing.Point(41, 30);
            this.Matrikelnummer.Name = "Matrikelnummer";
            this.Matrikelnummer.Size = new System.Drawing.Size(81, 13);
            this.Matrikelnummer.TabIndex = 13;
            this.Matrikelnummer.Text = "Matrikelnummer";
            // 
            // StudentenSuchen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2018, 649);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "StudentenSuchen";
            this.Text = "Studenten suchen";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TxtBoxEmail;
        private System.Windows.Forms.TextBox TxtBoxTelefon;
        private System.Windows.Forms.TextBox TxtBoxWohnort;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TxtBoxPLZ;
        private System.Windows.Forms.TextBox TxtBoxHausnummer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtBoxStrasse;
        private System.Windows.Forms.TextBox TxtBoxNationalität;
        private System.Windows.Forms.TextBox TxtBoxGeburtsort;
        private System.Windows.Forms.TextBox TxtBoxGeburtsdatum;
        private System.Windows.Forms.TextBox TxtBoxVorname;
        public System.Windows.Forms.TextBox TxtBoxNachname;
        private System.Windows.Forms.Button CmdStudentenSuchenTabelleStudenten;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label Semester;
        private System.Windows.Forms.TextBox TxtBoxSemester;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox TxtBoxStudienbeginn;
        private System.Windows.Forms.TextBox TxtBoxStudententyp;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox TxtBoxStudienende;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox ComboBoxPartnerhochschule;
        private System.Windows.Forms.ComboBox ComboBoxStudiengang;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button CmdPartnerhochschuleSuchen;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox TxtBoxKontaktperson;
        private System.Windows.Forms.TextBox TxtBoxLand;
        private System.Windows.Forms.TextBox TxtBoxOrt;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox TxtBoxEmailStudiengangsleitung;
        private System.Windows.Forms.TextBox TxtBoxTelefonStudiengangsleitung;
        private System.Windows.Forms.TextBox TxtBoxStudiengangsleiter;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button CmdStudiengangSuchen;
        private System.Windows.Forms.ComboBox ComboBoxStudiengangTblStudiengang;
        private System.Windows.Forms.ComboBox ComboBoxPartnerhochschuleTblAuslandssemester;
        private System.Windows.Forms.TextBox TxtBoxMatrikelNr;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button CmdVorlesungen;
        private System.Windows.Forms.Label Matrikelnummer;
        private System.Windows.Forms.TextBox textBox1;
    }
}