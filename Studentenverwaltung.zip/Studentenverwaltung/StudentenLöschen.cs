﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Studentenverwaltung
{
    public partial class StudentenLöschen : Form
    {
        public StudentenLöschen()
        {
            InitializeComponent();
            FillComboBoxPartnerhochschule();
            FillComboBoxStudiengang();
            FillComboBoxStudiengangTblStudiengang();
            FillComboBoxPartnerhochschuleTblAuslandssemester();
        }

        void FillComboBoxPartnerhochschule()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Hochschule from studentendaten.auslandssemester";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Hochschule = myReader.GetString("Hochschule");
                    ComboBoxPartnerhochschule.Items.Add(Hochschule);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        void FillComboBoxPartnerhochschuleTblAuslandssemester()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Hochschule from studentendaten.auslandssemester";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Hochschule = myReader.GetString("Hochschule");
                    ComboBoxPartnerhochschuleTblAuslandssemester.Items.Add(Hochschule);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        void FillComboBoxStudiengang()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Studiengang from studentendaten.studiengang";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Studiengang = myReader.GetString("Studiengang");
                    ComboBoxStudiengang.Items.Add(Studiengang);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        void FillComboBoxStudiengangTblStudiengang()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Studiengang from studentendaten.studiengang";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Studiengang = myReader.GetString("Studiengang");
                    ComboBoxStudiengangTblStudiengang.Items.Add(Studiengang);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private MySqlCommand command = null;
        private MySqlDataReader reader = null;

        //Studenten, den man löschen möchte, aus der Tabelle Studenten heraussuchen
        private void CmdStudentenSuchenTabelleStudenten_Click(object sender, EventArgs e)
        {
            string MatrikelNr = TxtBoxMatrikelNr.Text;
            string Nachname = TxtBoxNachname.Text;
            string Vorname = TxtBoxVorname.Text;
            string Studiengang = ComboBoxStudiengang.Text;
            string Semester = TxtBoxSemester.Text;
            string Studienbeginn = TxtBoxStudienbeginn.Text;
            string Studienende = TxtBoxStudienende.Text;
            string Studententyp = TxtBoxStudententyp.Text;
            string Partnerhochschule = ComboBoxPartnerhochschule.Text;
            string Geburtsdatum = TxtBoxGeburtsdatum.Text;
            string Geburtsort = TxtBoxGeburtsort.Text;
            string Nationalität = TxtBoxNationalität.Text;
            string Strasse = TxtBoxStrasse.Text;
            string Hausnummer = TxtBoxHausnummer.Text;
            string PLZ = TxtBoxPLZ.Text;
            string Wohnort = TxtBoxWohnort.Text;
            string Telefon = TxtBoxTelefon.Text;
            string Email = TxtBoxEmail.Text;

            string Suchen = "select * from studenten where Matrikelnummer LIKE '" + MatrikelNr + "%' and Nachname LIKE '%" + Nachname + "%'" + "and Vorname LIKE '%" + Vorname + "%'" + "and Studiengang LIKE '%" + Studiengang + "%'" + "and Semester LIKE '%" + Semester + "%'" + "and Studienbeginn LIKE '%" + Studienbeginn + "%'" + "and Studienende LIKE '%" + Studienende + "%'" + "and Studententyp LIKE '%" + Studententyp + "%'" + "and Partnerhochschule_Ausland LIKE '%" + Partnerhochschule + "%'" + "and Geburtsdatum LIKE '%" + Geburtsdatum + "%'" + "and Geburtsort LIKE '%" + Geburtsort + "%'" + "and Nationalität LIKE '%" + Nationalität + "%'" + "and Strasse LIKE '%" + Strasse + "%'" + "and Hausnummer LIKE '%" + Hausnummer + "%'" + "and PLZ LIKE '%" + PLZ + "%'" + "and Wohnort LIKE '%" + Wohnort + "%'" + "and Telefon LIKE '%" + Telefon + "%'" + "and Email LIKE '%" + Email + "%'";

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
            try
            {
                connection.Open();
                command = new MySqlCommand(Suchen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;

                reader = command.ExecuteReader();

                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            groupBox2.Visible = true;
            CmdStudentenLöschen.Visible = true;
        }

        //Herausgesuchten Studenten in der DataGridView anwählen und mit dem Löschen-Button aus der Datenbank entfernen 
        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
        private void CmdStudentenLöschen_Click(object sender, EventArgs e)
        {
            try
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];
                int zelleMatrikelNr = (int)row.Cells[0].Value;
                string Löschen = "delete from studenten where Matrikelnummer=" + zelleMatrikelNr;

                connection.Open();
                command = new MySqlCommand(Löschen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                MessageBox.Show("Student wurde erfolgreich gelöscht");

                reader.Close();
                connection.Close();
            }
            catch
            {
                MessageBox.Show("Bitte wählen Sie einen Studentendatensatz aus.");
            }
        }

        //Studiengang, den man löschen möchte, aus der Tabelle Studiengang heraussuchen
        private void CmdStudiengangSuchen_Click(object sender, EventArgs e)
        {
            string StudiengangTblStudiengang = ComboBoxStudiengangTblStudiengang.Text;
            string Studiengangsleiter = TxtBoxStudiengangsleiter.Text;
            string TelefonStudiengangsleitung = TxtBoxTelefonStudiengangsleitung.Text;
            string EmailStudiengangsleitung = TxtBoxEmailStudiengangsleitung.Text;

            string Suchen = "select * from studiengang where Studiengang LIKE '%" + StudiengangTblStudiengang + "%'" + "and Studiengangsleiter LIKE '%" + Studiengangsleiter + "%'" + "and Telefon_Studiengangsleitung LIKE '%" + TelefonStudiengangsleitung + "%'" + "and Email_Studiengangsleitung LIKE '%" + EmailStudiengangsleitung + "%'";

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
            try
            {
                connection.Open();
                command = new MySqlCommand(Suchen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;

                reader = command.ExecuteReader();

                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            groupBox2.Visible = true;
            CmdStudiengangLöschen.Visible = true;
        }

        //Herausgesuchten Studiengang in der DataGridView anwählen und mit dem Löschen-Button aus der Datenbank entfernen 
        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                //Überprüfen, ob der zu löschende Studiengang von Studenten besucht wird und wenn ja, Hinweis geben, dass dies nicht geht
                MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                DataGridViewRow rowZuLöschenderStudiengang = dataGridView1.SelectedRows[0];
                string zuLöschenderStudiengang = (string)rowZuLöschenderStudiengang.Cells[0].Value;
                
                string Suchen = "select Studiengang from studenten where Studiengang='" + zuLöschenderStudiengang + "'";

                connection.Open();
                command = new MySqlCommand(Suchen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                DataTable dt2 = new DataTable();
                dt2.Load(reader);
                DataGridViewLöschenStudiengang.DataSource = dt2;

                reader = command.ExecuteReader();

                reader.Close();
                connection.Close();

                //Zusätzliche unsichtbare DataGridView um den Wert aus der ersten Zeile und ersten Splate entnehmen zu können, bzw um zu schauen, ob ein Student den Studiengang besucht oder nicht
                DataGridViewRow row2 = DataGridViewLöschenStudiengang.Rows[0];
                string besuchterStudiengang = (string)row2.Cells[0].Value;
                
               
               //Sichtbare DataGridView zum Auswählen des zu löschenden Datensatzes
                DataGridViewRow row = dataGridView1.SelectedRows[0];
                string zelleStudiengang = (string)row.Cells[0].Value;

                //Falls ein Student den eingegebenen Studiengang besucht, wird der besuchte Studiengang in dem string "besuchterStudiengang" gespeichert, sodass dann verglichen werden kann, ob der besuchte Studiengang mit dem ausgewählten übereinstimmt
                //In diesem Fall, soll ein Hinweis gegeben werden, dass kein Studiengang gelöscht werden kann, welcher auch besucht wird
               if (besuchterStudiengang == zelleStudiengang )
                {
                    MessageBox.Show("Dieser Studiengang wird von Studenten besucht und kann daher nicht gelöscht werden");
                }
               else //Falls der ausgewählte Studiengang von keinem Studenten besucht wird, so soll dieser Studiengang gelöscht werden
                {
                string Löschen = "delete from studiengang where Studiengang='" + zelleStudiengang + "'"; 

                connection.Open();
                command = new MySqlCommand(Löschen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                MessageBox.Show("Studiengang wurde erfolgreich gelöscht");

                reader.Close();
                connection.Close();
                }                
            }
            catch
            {
               MessageBox.Show("Bitte wählen Sie einen Datensatz aus");
            }

        }
      
        //Partnerhochschule, die man löschen möchte, aus der Tabelle Auslandssemester heraussuchen
        private void CmdPartnerhochschuleSuchen_Click(object sender, EventArgs e)
        {
            string PartnerhochschuleTblAuslandssemester = ComboBoxPartnerhochschuleTblAuslandssemester.Text;
            string Ort = TxtBoxOrt.Text;
            string Land = TxtBoxLand.Text;
            string Kontaktperson = TxtBoxKontaktperson.Text;

            string Suchen = "select * from auslandssemester where Hochschule LIKE '%" + PartnerhochschuleTblAuslandssemester + "%'" + "and Ort LIKE '%" + Ort + "%'" + "and Land LIKE '%" + Land + "%'" + "and Kontaktperson LIKE '%" + Kontaktperson + "%'";

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
            try
            {
                connection.Open();
                command = new MySqlCommand(Suchen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;

                reader = command.ExecuteReader();

                reader.Close();
                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            groupBox2.Visible = true;
            CmdPartnerhochschuleLöschen.Visible = true;
        }

        //Herausgesuchte Partnerhochschule in der DataGridView anwählen und mit dem Löschen-Button aus der Datenbank entfernen
        private void CmdPartnerhochschuleLöschen_Click(object sender, EventArgs e)
        {
            try
            {
                //Überprüfen, ob die zu löschende Partnerhochschule von Studenten besucht wird und wenn ja, Hinweis geben, dass dies nicht geht
                MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                DataGridViewRow rowZuLöschendePartnerhochschule = dataGridView1.SelectedRows[0];
                string zuLöschendePartnerhochschule = (string)rowZuLöschendePartnerhochschule.Cells[0].Value;
                
                string Suchen = "select Partnerhochschule_Ausland from studenten where Partnerhochschule_Ausland='" + zuLöschendePartnerhochschule + "'";

                connection.Open();
                command = new MySqlCommand(Suchen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                DataTable dt3 = new DataTable();
                dt3.Load(reader);
                DataGridViewLöschenAuslandssemester.DataSource = dt3;

                reader = command.ExecuteReader();

                reader.Close();
                connection.Close();

                //Zusätzliche unsichtbare DataGridView um den Wert aus der ersten Zeile und ersten Splate entnehmen zu können, bzw um zu schauen, ob ein Student die Partnerhochschule besucht oder nicht
                DataGridViewRow row3 = DataGridViewLöschenAuslandssemester.Rows[0];
                string besuchtePartnerhochschule = (string)row3.Cells[0].Value;

                //Sichtbare DataGridView zum Auswählen des zu löschenden Datensatzes
                DataGridViewRow row = dataGridView1.SelectedRows[0];
                string zellePartnerhochschule = (string)row.Cells[0].Value;

                //Falls ein Student die eingegebene Partnerhochschule besucht, wird die besuchte Partnerhochschule in dem string "besuchtePartnerhochschule" gespeichert, sodass dann verglichen werden kann, ob die besuchte Partnerhochschule mit der ausgewählten übereinstimmt
                //In diesem Fall, soll ein Hinweis gegeben werden, dass keine Partnerhochschule gelöscht werden kann, welche auch besucht wird
                if (besuchtePartnerhochschule == zellePartnerhochschule)
                {
                    MessageBox.Show("Diese Partnerhochschule wird von Studenten besucht und kann daher nicht gelöscht werden");
                }
                else //Falls die ausgewählte Partnerhochschule von keinem Studenten besucht wird, so soll diese Partnerhochschule gelöscht werden
                {
                    string Löschen = "delete from auslandssemester where Hochschule='" + zellePartnerhochschule + "'";

                    connection.Open();
                    command = new MySqlCommand(Löschen);
                    command.Connection = connection;
                    reader = command.ExecuteReader();

                    MessageBox.Show("Partnerhochschule wurde erfolgreich gelöscht");

                    reader.Close();
                    connection.Close();
                }
            }
            catch
            {
                MessageBox.Show("Bitte wählen Sie einen Datensatz aus");
            }
        }
    }
}
