﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Studentenverwaltung
{
    public partial class StudentenÄndern : Form
    {
        public StudentenÄndern()
        {
            InitializeComponent();
            FillComboBoxPartnerhochschule();
            FillComboBoxStudiengang();
            FillComboBoxPartnerhochschuleTblAuslandssemester();
            FillComboBoxStudiengangTblStudiengang();
        }

        //Combobox der Partnerhochschule mit den Attribut-Werten der Datenbank befüllen
        void FillComboBoxPartnerhochschule()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Hochschule from studentendaten.auslandssemester";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Hochschule = myReader.GetString("Hochschule");
                    ComboBoxPartnerhochschule.Items.Add(Hochschule);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Combobox der Partnerhochschule im Feld Partnerhochschule ändern mit den Attribut-Werten der Datenbank befüllen
        void FillComboBoxPartnerhochschuleTblAuslandssemester()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Hochschule from studentendaten.auslandssemester";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Hochschule = myReader.GetString("Hochschule");
                    ComboBoxPartnerhochschuleTblAuslandssemester.Items.Add(Hochschule);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Combobox des Studiengangs mit den Attribut-Werten der Datenbank befüllen
        void FillComboBoxStudiengang()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Studiengang from studentendaten.studiengang";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Studiengang = myReader.GetString("Studiengang");
                    ComboBoxStudiengang.Items.Add(Studiengang);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Combobox des Studiengangs im Feld Studiengang ändern mit den Attribut-Werten der Datenbank befüllen
        void FillComboBoxStudiengangTblStudiengang()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Studiengang from studentendaten.studiengang";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Studiengang = myReader.GetString("Studiengang");
                    ComboBoxStudiengangTblStudiengang.Items.Add(Studiengang);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private MySqlCommand command = null;
        private MySqlDataReader reader = null;


        //Tabelle Studenten:

        // Zu ändernde Studentendaten suchen und in der DataGridView ausgeben
        private void CmdStudentenSuchenTabelleStudenten_Click(object sender, EventArgs e)
        {
            string MatrikelNr = TxtBoxMatrikelNr.Text;
            string Nachname = TxtBoxNachname.Text;
            string Vorname = TxtBoxVorname.Text;
            string Studiengang = ComboBoxStudiengang.Text;
            string Semester = TxtBoxSemester.Text;
            string Studienbeginn = TxtBoxStudienbeginn.Text;
            string Studienende = TxtBoxStudienende.Text;
            string Studententyp = TxtBoxStudententyp.Text;
            string Partnerhochschule = ComboBoxPartnerhochschule.Text;
            string Geburtsdatum = TxtBoxGeburtsdatum.Text;
            string Geburtsort = TxtBoxGeburtsort.Text;
            string Nationalität = TxtBoxNationalität.Text;
            string Strasse = TxtBoxStrasse.Text;
            string Hausnummer = TxtBoxHausnummer.Text;
            string PLZ = TxtBoxPLZ.Text;
            string Wohnort = TxtBoxWohnort.Text;
            string Telefon = TxtBoxTelefon.Text;
            string Email = TxtBoxEmail.Text;

            string Suchen = "select * from studenten where Matrikelnummer LIKE '" + MatrikelNr + "%' and Nachname LIKE '%" + Nachname + "%'" + "and Vorname LIKE '%" + Vorname + "%'" + "and Studiengang LIKE '%" + Studiengang + "%'" + "and Semester LIKE '%" + Semester + "%'" + "and Studienbeginn LIKE '%" + Studienbeginn + "%'" + "and Studienende LIKE '%" + Studienende + "%'" + "and Studententyp LIKE '%" + Studententyp + "%'" + "and Partnerhochschule_Ausland LIKE '%" + Partnerhochschule + "%'" + "and Geburtsdatum LIKE '%" + Geburtsdatum + "%'" + "and Geburtsort LIKE '%" + Geburtsort + "%'" + "and Nationalität LIKE '%" + Nationalität + "%'" + "and Strasse LIKE '%" + Strasse + "%'" + "and Hausnummer LIKE '%" + Hausnummer + "%'" + "and PLZ LIKE '%" + PLZ + "%'" + "and Wohnort LIKE '%" + Wohnort + "%'" + "and Telefon LIKE '%" + Telefon + "%'" + "and Email LIKE '%" + Email + "%'";

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
            try
            {
                connection.Open();
                command = new MySqlCommand(Suchen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;

                reader = command.ExecuteReader();

                reader.Close();
                connection.Close();
                GroupBoxStudentendatensatzAuswählen.Visible = true;
                CmdStudentenLöschen.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        
        //Ausgewählten Datensatz aus der Studenten-Tabelle nun so in den Textboxen aufbereiten, dass der Benutzer einzelne Werte leicht ändern kann
        private void CmdStudentenLöschen_Click(object sender, EventArgs e)
        {
            ComboBoxPartnerhochschule.Text = "keine";
            ComboBoxStudiengang.Text = "WIW-ITP";

            TxtBoxMatrikelNr.Visible = false;
            LblMatrikelNr.Visible = false;

            try
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];

                //Matrikelnummer
                int MatrikelNr = (int)row.Cells[0].Value;
                string MatrikelNr2 = Convert.ToString(MatrikelNr);
                TxtBoxMatrikelNr.Text = MatrikelNr2;

                //Nachname
                string Nachname = (string)row.Cells[1].Value;
                TxtBoxNachname.Text = Nachname;

                //Vorname
                string Vorname = (string)row.Cells[2].Value;
                TxtBoxVorname.Text = Vorname;

                //Studiengang
                string Studiengang = (string)row.Cells[3].Value;
                ComboBoxStudiengang.Text = Studiengang;

                //Semester
                string Semester = (string)row.Cells[4].Value;
                TxtBoxSemester.Text = Semester;

                //Studienbeginn
                string Studienbeginn = (string)row.Cells[5].Value;
                TxtBoxStudienbeginn.Text = Studienbeginn;

                //Studienende
                string Studienende = (string)row.Cells[6].Value;
                TxtBoxStudienende.Text = Studienende;

                //Studententyp
                string Studententyp = (string)row.Cells[7].Value;
                TxtBoxStudententyp.Text = Studententyp;

                //Partnerhochschule
                string Partnerhochschule = (string)row.Cells[8].Value;
                ComboBoxPartnerhochschule.Text = Partnerhochschule;

                //Geburtsdatum
                string Geburtsdatum = (string)row.Cells[9].Value;
                TxtBoxGeburtsdatum.Text = Geburtsdatum;

                //Geburtsort
                string Geburtsort = (string)row.Cells[10].Value;
                TxtBoxGeburtsort.Text = Geburtsort;

                //Nationalität
                string Nationalität = (string)row.Cells[11].Value;
                TxtBoxNationalität.Text = Nationalität;

                //Strasse 
                string Strasse = (string)row.Cells[12].Value;
                TxtBoxStrasse.Text = Strasse;

                //Hausnummer
                string Hausnummer = (string)row.Cells[13].Value;
                TxtBoxHausnummer.Text = Hausnummer;

                //PLZ
                string PLZ = (string)row.Cells[14].Value;
                TxtBoxPLZ.Text = PLZ;

                //Wohnort
                string Wohnort = (string)row.Cells[15].Value;
                TxtBoxWohnort.Text = Wohnort;

                //Telefon
                string Telefon = (string)row.Cells[16].Value;
                TxtBoxTelefon.Text = Telefon;

                //Email
                string Email = (string)row.Cells[17].Value;
                TxtBoxEmail.Text = Email;


                GroupBoxStudentendatensatzAuswählen.Visible = false;
                
                CmdStudentenLöschen.Visible = false;
                CmdÄnderungSpeichern.Visible = true;
                CmdStudentenSuchenTabelleStudenten.Visible = false;
                GroupBoxStudentendatensatzAuswählen.Text = "Studentendaten bearbeiten";              
            }
            catch(Exception)
            {
                MessageBox.Show("Bitte wählen Sie einen Datensatz aus.");
            }            
        }

        //Vorgenommene Änderungen am Datensatz aus der Studenten-Tabelle speichern
        private void CmdÄnderungSpeichern_Click(object sender, EventArgs e)
        {
            string MatrikelNr = TxtBoxMatrikelNr.Text;
            string Nachname = TxtBoxNachname.Text;
            string Vorname = TxtBoxVorname.Text;
            string Studiengang = ComboBoxStudiengang.Text;
            string Semester = TxtBoxSemester.Text;
            string Studienbeginn = TxtBoxStudienbeginn.Text;
            string Studienende = TxtBoxStudienende.Text;
            string Studententyp = TxtBoxStudententyp.Text;
            string Partnerhochschule = ComboBoxPartnerhochschule.Text;
            string Geburtsdatum = TxtBoxGeburtsdatum.Text;
            string Geburtsort = TxtBoxGeburtsort.Text;
            string Nationalität = TxtBoxNationalität.Text;
            string Strasse = TxtBoxStrasse.Text;
            string Hausnummer = TxtBoxHausnummer.Text;
            string PLZ = TxtBoxPLZ.Text;
            string Wohnort = TxtBoxWohnort.Text;
            string Telefon = TxtBoxTelefon.Text;
            string Email = TxtBoxEmail.Text;

            DataGridViewRow row = dataGridView1.SelectedRows[0];
            int Matrikelnummer = (int)row.Cells[0].Value;
            string MatrikelNrString;
            MatrikelNrString = Matrikelnummer.ToString();
                     
            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
         
            string Ändern = "update studenten set Matrikelnummer='" + MatrikelNr + "', Nachname='" + Nachname + "', Vorname='" + Vorname + "', Studiengang='" + Studiengang + "',Semester='" + Semester + "',Studienbeginn='" + Studienbeginn + "',Studienende='" + Studienende + "',Studententyp='" + Studententyp + "',Partnerhochschule_Ausland='" + Partnerhochschule + "', Geburtsdatum='" + Geburtsdatum + "', Geburtsort='" + Geburtsort + "', Nationalität='" + Nationalität + "', Strasse='" + Strasse + "', Hausnummer='" + Hausnummer + "', PLZ='" + PLZ + "', Wohnort='" + Wohnort + "', Telefon='" + Telefon + "', Email='" + Email + "' where Matrikelnummer='" + MatrikelNrString + "'";

                                          
            try
            {
                    if(ComboBoxStudiengang.Text == "")
                    {
                          MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                    }
                    else if (ComboBoxPartnerhochschule.Text == "")
                   {
                          MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                   }                  
                else
                {
                   connection.Open();
                   command = new MySqlCommand(Ändern);
                   command.Connection = connection;
                   reader = command.ExecuteReader();
                   
                   MessageBox.Show("Studentendaten wurden erfolgreich geändert");
                    TxtBoxMatrikelNr.Text = "";
                    TxtBoxNachname.Text = "";
                    TxtBoxVorname.Text = "";
                    ComboBoxStudiengang.Text = "";
                    TxtBoxSemester.Text = "";
                    TxtBoxStudienbeginn.Text = "";
                    TxtBoxStudienende.Text = "";
                    TxtBoxStudententyp.Text = "";
                    ComboBoxPartnerhochschule.Text = "";
                    TxtBoxGeburtsdatum.Text = "";
                    TxtBoxGeburtsort.Text = "";
                    TxtBoxNationalität.Text = "";
                    TxtBoxStrasse.Text = "";
                    TxtBoxHausnummer.Text = "";
                    TxtBoxPLZ.Text = "";
                    TxtBoxWohnort.Text = "";
                    TxtBoxTelefon.Text = "";
                    TxtBoxEmail.Text = "";

                    CmdStudentenSuchenTabelleStudenten.Visible = true;
                    CmdÄnderungSpeichern.Visible = false;

                    TxtBoxMatrikelNr.Visible = true;
                    LblMatrikelNr.Visible = true;

                    reader.Close();
                   connection.Close();     
                }
                            
               }
               catch(Exception ex)
               {
                MessageBox.Show(ex.Message);
               }            
        }


        //Tabelle Studiengang:

        // Zu ändernde Studiengangsdaten suchen und in der DataGridView ausgeben
        private void CmdStudiengangsdatenSuchen_Click(object sender, EventArgs e)
        {
            string StudiengangTblStudiengang = ComboBoxStudiengangTblStudiengang.Text;
            string Studiengangsleiter = TxtBoxStudiengangsleiter.Text;
            string TelefonStudiengangsleitung = TxtBoxTelefonStudiengangsleitung.Text;
            string EmailStudiengangsleitung = TxtBoxEmailStudiengangsleitung.Text;

            string Suchen = "select * from studiengang where Studiengang LIKE '%" + StudiengangTblStudiengang + "%'" + "and Studiengangsleiter LIKE '%" + Studiengangsleiter + "%'" + "and Telefon_Studiengangsleitung LIKE '%" + TelefonStudiengangsleitung + "%'" + "and Email_Studiengangsleitung LIKE '%" + EmailStudiengangsleitung + "%'";

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
            try
            {
                connection.Open();
                command = new MySqlCommand(Suchen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;

                reader = command.ExecuteReader();

                reader.Close();
                connection.Close();
                GroupBoxStudentendatensatzAuswählen.Visible = true;
                CmdStudentendatensatzAuswählen.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }

        //Ausgewählten Datensatz aus der Studiengangs-Tabelle nun so in den Textboxen aufbereiten, dass der Benutzer einzelne Werte leicht ändern kann
        private void CmdStudentendatensatzAuswählen_Click(object sender, EventArgs e)
        {
            try
            {
                ComboBoxStudiengangTblStudiengang.Visible = false;
                LblStudiengang.Visible = false;

                DataGridViewRow row = dataGridView1.SelectedRows[0];

                //Studiengang
                string StudiengangTblStudiengang = (string)row.Cells[0].Value;
                ComboBoxStudiengangTblStudiengang.Text = StudiengangTblStudiengang;

                //Studiengangsleiter
                string Studiengangsleiter = (string)row.Cells[1].Value;
                TxtBoxStudiengangsleiter.Text = Studiengangsleiter;

                //Telefon Studiengangsleitung
                string TelefonStudiengangsleitung = (string)row.Cells[2].Value;
                TxtBoxTelefonStudiengangsleitung.Text = TelefonStudiengangsleitung;

                //Email Studiengangangsleitung
                string EmailStudiengangsleitung = (string)row.Cells[3].Value;
                TxtBoxEmailStudiengangsleitung.Text = EmailStudiengangsleitung;
              


                GroupBoxStudentendatensatzAuswählen.Visible = false;

                CmdStudentendatensatzAuswählen.Visible = false;
                CmdÄnderungSpeichernStudiengang.Visible = true;
                CmdStudiengangsdatenSuchen.Visible = false;
                GroupBoxStudentendatensatzAuswählen.Text = "Studentendaten bearbeiten";
            }
            catch (Exception)
            {
                MessageBox.Show("Bitte wählen Sie einen Datensatz aus.");
            }
        }
        
        //Vorgenommene Änderungen am Datensatz aus der Studiengangs-Tabelle speichern
        private void CmdÄnderungSpeichernStudiengang_Click(object sender, EventArgs e)
        {
            string StudiengangTblStudiengang = ComboBoxStudiengangTblStudiengang.Text;
            string Studiengangsleiter = TxtBoxStudiengangsleiter.Text;
            string TelefonStudiengangsleitung = TxtBoxTelefonStudiengangsleitung.Text;
            string EmailStudiengangsleitung = TxtBoxEmailStudiengangsleitung.Text;

            DataGridViewRow row = dataGridView1.SelectedRows[0];
            string StudiengangPrimäSchlüssel = (string)row.Cells[0].Value;
            
            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

            string Ändern = "update studiengang set Studiengang='" + StudiengangTblStudiengang + "', Studiengangsleiter='" + Studiengangsleiter + "', Telefon_Studiengangsleitung='" + TelefonStudiengangsleitung + "',Email_Studiengangsleitung='" + EmailStudiengangsleitung + "' where Studiengang='" + StudiengangPrimäSchlüssel + "'";

            try
            {
                if(ComboBoxStudiengangTblStudiengang.Text == "")
                {
                    MessageBox.Show("Bitte lassen Sie das Studiengangsfeld nicht leer");
                }
                else
                {
                connection.Open();
                command = new MySqlCommand(Ändern);
                command.Connection = connection;
                reader = command.ExecuteReader();

                MessageBox.Show("Studiengangsdaten wurden erfolgreich geändert");
                ComboBoxStudiengangTblStudiengang.Text = "";
                TxtBoxStudiengangsleiter.Text = "";
                TxtBoxTelefonStudiengangsleitung.Text = "";
                TxtBoxEmailStudiengangsleitung.Text = "";
                CmdStudiengangsdatenSuchen.Visible = true;
                CmdÄnderungSpeichernStudiengang.Visible = false;

                    ComboBoxStudiengangTblStudiengang.Visible = true;
                    LblStudiengang.Visible = true;

                    reader.Close();
                connection.Close();
                }
               
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        


        //Tabelle Auslandssemester:

        // Zu ändernde Partnerhochschuldaten suchen und in der DataGridView ausgeben
        private void CmdPartnerhochschuldatenSuchen_Click(object sender, EventArgs e)
        {
            string PartnerhochschuleTblAuslandssemester = ComboBoxPartnerhochschuleTblAuslandssemester.Text;
            string Ort = TxtBoxOrt.Text;
            string Land = TxtBoxLand.Text;
            string Kontaktperson = TxtBoxKontaktperson.Text;

            string Suchen = "select * from auslandssemester where Hochschule LIKE '%" + PartnerhochschuleTblAuslandssemester + "%'" + "and Ort LIKE '%" + Ort + "%'" + "and Land LIKE '%" + Land + "%'" + "and Kontaktperson LIKE '%" + Kontaktperson + "%'";

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
            try
            {
                connection.Open();
                command = new MySqlCommand(Suchen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                DataTable dt = new DataTable();
                dt.Load(reader);
                dataGridView1.DataSource = dt;

                reader = command.ExecuteReader();

                reader.Close();
                connection.Close();
                GroupBoxStudentendatensatzAuswählen.Visible = true;
                CmdPartnerhochschuldatensatzAuswählen.Visible = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
     
        //Ausgewählten Datensatz aus der Auslandssemester-Tabelle nun so in den Textboxen aufbereiten, dass der Benutzer einzelne Werte leicht ändern kann
        private void CmdPartnerhochschuldatensatzAuswählen_Click(object sender, EventArgs e)
        {
            try
            {
                ComboBoxPartnerhochschuleTblAuslandssemester.Visible = false;
                LblHochschule.Visible = false;

                DataGridViewRow row = dataGridView1.SelectedRows[0];

                //Partnerhochschule
                string PartnerhoschuleTblAuslandssemester = (string)row.Cells[0].Value;
                ComboBoxPartnerhochschuleTblAuslandssemester.Text = PartnerhoschuleTblAuslandssemester;

                //Ort
                string Ort = (string)row.Cells[1].Value;
                TxtBoxOrt.Text = Ort;

                //Land
                string Land = (string)row.Cells[2].Value;
                TxtBoxLand.Text = Land;

                //Kontaktperson
                string Kontaktperson = (string)row.Cells[3].Value;
                TxtBoxKontaktperson.Text = Kontaktperson;



                GroupBoxStudentendatensatzAuswählen.Visible = false;

                CmdPartnerhochschuldatensatzAuswählen.Visible = false;
                CmdÄnderungSpeichernAuslandssemester.Visible = true;
                CmdPartnerhochschuldatenSuchen.Visible = false;
                GroupBoxStudentendatensatzAuswählen.Text = "Studentendaten bearbeiten";
            }
            catch (Exception)
            {
                MessageBox.Show("Bitte wählen Sie einen Datensatz aus.");
            }
        }

        //Vorgenommene Änderungen am Datensatz aus der Auslandssemester-Tabelle speichern
        private void CmdÄnderungSpeichernAuslandssemester_Click(object sender, EventArgs e)
        {
            string PartnerhochschuleTblAuslandssemester = ComboBoxPartnerhochschuleTblAuslandssemester.Text;
            string Ort = TxtBoxOrt.Text;
            string Land = TxtBoxLand.Text;
            string Kontaktperson = TxtBoxKontaktperson.Text;

            DataGridViewRow row = dataGridView1.SelectedRows[0];
            string HochschulPrimäSchlüssel = (string)row.Cells[0].Value;

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

            string Ändern = "update auslandssemester set Hochschule='" + PartnerhochschuleTblAuslandssemester + "', Ort='" + Ort + "', Land='" + Land + "',Kontaktperson='" + Kontaktperson + "' where Hochschule='" + HochschulPrimäSchlüssel + "'";

            try
            {
                if(ComboBoxPartnerhochschuleTblAuslandssemester.Text == "")
                {
                    MessageBox.Show("Bitte lassen Sie das Hochschulfeld nicht leeer");
                }
                else
                {
                 connection.Open();
                command = new MySqlCommand(Ändern);
                command.Connection = connection;
                reader = command.ExecuteReader();

                MessageBox.Show("Partnerhochschuldaten wurden erfolgreich geändert");
                ComboBoxPartnerhochschuleTblAuslandssemester.Text = "";
                TxtBoxOrt.Text = "";
                TxtBoxLand.Text = "";
                TxtBoxKontaktperson.Text = "";
                CmdPartnerhochschuldatenSuchen.Visible = true;
                CmdÄnderungSpeichernAuslandssemester.Visible = false;

                    ComboBoxPartnerhochschuleTblAuslandssemester.Visible = true;
                    LblHochschule.Visible = true;

                    reader.Close();
                connection.Close();
                }
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
