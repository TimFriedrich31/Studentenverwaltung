﻿namespace Studentenverwaltung
{
    partial class Studentenverwaltung
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.CmdBeenden = new System.Windows.Forms.Button();
            this.CmdAnlegen = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.CmdSuchen = new System.Windows.Forms.Button();
            this.CmdÄndern = new System.Windows.Forms.Button();
            this.CmdLöschen = new System.Windows.Forms.Button();
            this.lbltest = new System.Windows.Forms.Label();
            this.LblVerbunden = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LblGetrennt = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CmdBeenden
            // 
            this.CmdBeenden.Location = new System.Drawing.Point(604, 119);
            this.CmdBeenden.Name = "CmdBeenden";
            this.CmdBeenden.Size = new System.Drawing.Size(103, 23);
            this.CmdBeenden.TabIndex = 1;
            this.CmdBeenden.Text = "Beenden";
            this.CmdBeenden.UseVisualStyleBackColor = true;
            this.CmdBeenden.Click += new System.EventHandler(this.CmdBeenden_Click);
            // 
            // CmdAnlegen
            // 
            this.CmdAnlegen.Location = new System.Drawing.Point(6, 47);
            this.CmdAnlegen.Name = "CmdAnlegen";
            this.CmdAnlegen.Size = new System.Drawing.Size(124, 23);
            this.CmdAnlegen.TabIndex = 2;
            this.CmdAnlegen.Text = "Anlegen";
            this.CmdAnlegen.UseVisualStyleBackColor = true;
            this.CmdAnlegen.Click += new System.EventHandler(this.CmdAnlegen_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.CmdSuchen);
            this.groupBox1.Controls.Add(this.CmdÄndern);
            this.groupBox1.Controls.Add(this.CmdLöschen);
            this.groupBox1.Controls.Add(this.CmdAnlegen);
            this.groupBox1.Location = new System.Drawing.Point(40, 119);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(529, 117);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Studentendaten ";
            // 
            // CmdSuchen
            // 
            this.CmdSuchen.Location = new System.Drawing.Point(396, 47);
            this.CmdSuchen.Name = "CmdSuchen";
            this.CmdSuchen.Size = new System.Drawing.Size(124, 23);
            this.CmdSuchen.TabIndex = 5;
            this.CmdSuchen.Text = "Suchen";
            this.CmdSuchen.UseVisualStyleBackColor = true;
            this.CmdSuchen.Click += new System.EventHandler(this.CmdSuchen_Click);
            // 
            // CmdÄndern
            // 
            this.CmdÄndern.Location = new System.Drawing.Point(266, 47);
            this.CmdÄndern.Name = "CmdÄndern";
            this.CmdÄndern.Size = new System.Drawing.Size(124, 23);
            this.CmdÄndern.TabIndex = 4;
            this.CmdÄndern.Text = "Ändern";
            this.CmdÄndern.UseVisualStyleBackColor = true;
            this.CmdÄndern.Click += new System.EventHandler(this.CmdÄndern_Click);
            // 
            // CmdLöschen
            // 
            this.CmdLöschen.Location = new System.Drawing.Point(136, 47);
            this.CmdLöschen.Name = "CmdLöschen";
            this.CmdLöschen.Size = new System.Drawing.Size(124, 23);
            this.CmdLöschen.TabIndex = 3;
            this.CmdLöschen.Text = "Löschen";
            this.CmdLöschen.UseVisualStyleBackColor = true;
            this.CmdLöschen.Click += new System.EventHandler(this.CmdLöschen_Click);
            // 
            // lbltest
            // 
            this.lbltest.AutoSize = true;
            this.lbltest.Location = new System.Drawing.Point(43, 77);
            this.lbltest.Name = "lbltest";
            this.lbltest.Size = new System.Drawing.Size(153, 13);
            this.lbltest.TabIndex = 4;
            this.lbltest.Text = "Datenbank-Verbindungsstatus:";
            // 
            // LblVerbunden
            // 
            this.LblVerbunden.AutoSize = true;
            this.LblVerbunden.BackColor = System.Drawing.Color.Lime;
            this.LblVerbunden.Location = new System.Drawing.Point(202, 77);
            this.LblVerbunden.Name = "LblVerbunden";
            this.LblVerbunden.Size = new System.Drawing.Size(59, 13);
            this.LblVerbunden.TabIndex = 5;
            this.LblVerbunden.Text = "Verbunden";
            this.LblVerbunden.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(144, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 6;
            this.label1.Visible = false;
            // 
            // LblGetrennt
            // 
            this.LblGetrennt.AutoSize = true;
            this.LblGetrennt.BackColor = System.Drawing.Color.Red;
            this.LblGetrennt.Location = new System.Drawing.Point(202, 77);
            this.LblGetrennt.Name = "LblGetrennt";
            this.LblGetrennt.Size = new System.Drawing.Size(48, 13);
            this.LblGetrennt.TabIndex = 7;
            this.LblGetrennt.Text = "Getrennt";
            this.LblGetrennt.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 25);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(471, 27);
            this.label2.TabIndex = 8;
            this.label2.Text = "Hochschule StudBW - Studentenverwaltung";
            // 
            // Studentenverwaltung
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 606);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.LblGetrennt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LblVerbunden);
            this.Controls.Add(this.lbltest);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.CmdBeenden);
            this.Name = "Studentenverwaltung";
            this.Text = "Studentenverwaltung";
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button CmdBeenden;
        private System.Windows.Forms.Button CmdAnlegen;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button CmdSuchen;
        private System.Windows.Forms.Button CmdÄndern;
        private System.Windows.Forms.Button CmdLöschen;
        private System.Windows.Forms.Label lbltest;
        private System.Windows.Forms.Label LblVerbunden;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LblGetrennt;
        private System.Windows.Forms.Label label2;
    }
}

