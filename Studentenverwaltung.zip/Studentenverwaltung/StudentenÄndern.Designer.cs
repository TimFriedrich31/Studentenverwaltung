﻿namespace Studentenverwaltung
{
    partial class StudentenÄndern
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CmdStudentenSuchenTabelleStudenten = new System.Windows.Forms.Button();
            this.GroupBoxStudentendatensatzAussuchen = new System.Windows.Forms.GroupBox();
            this.LblMatrikelNr = new System.Windows.Forms.Label();
            this.TxtBoxMatrikelNr = new System.Windows.Forms.TextBox();
            this.ComboBoxPartnerhochschule = new System.Windows.Forms.ComboBox();
            this.ComboBoxStudiengang = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.TxtBoxStudententyp = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.TxtBoxStudienende = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.TxtBoxStudienbeginn = new System.Windows.Forms.TextBox();
            this.Semester = new System.Windows.Forms.Label();
            this.TxtBoxSemester = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TxtBoxEmail = new System.Windows.Forms.TextBox();
            this.TxtBoxTelefon = new System.Windows.Forms.TextBox();
            this.TxtBoxWohnort = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.TxtBoxPLZ = new System.Windows.Forms.TextBox();
            this.TxtBoxHausnummer = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TxtBoxStrasse = new System.Windows.Forms.TextBox();
            this.TxtBoxNationalität = new System.Windows.Forms.TextBox();
            this.TxtBoxGeburtsort = new System.Windows.Forms.TextBox();
            this.TxtBoxGeburtsdatum = new System.Windows.Forms.TextBox();
            this.TxtBoxVorname = new System.Windows.Forms.TextBox();
            this.TxtBoxNachname = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.CmdStudentenLöschen = new System.Windows.Forms.Button();
            this.GroupBoxStudentendatensatzAuswählen = new System.Windows.Forms.GroupBox();
            this.CmdÄnderungSpeichern = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.CmdStudentendatensatzAuswählen = new System.Windows.Forms.Button();
            this.CmdÄnderungSpeichernStudiengang = new System.Windows.Forms.Button();
            this.CmdStudiengangsdatenSuchen = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ComboBoxStudiengangTblStudiengang = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.TxtBoxEmailStudiengangsleitung = new System.Windows.Forms.TextBox();
            this.TxtBoxTelefonStudiengangsleitung = new System.Windows.Forms.TextBox();
            this.TxtBoxStudiengangsleiter = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.LblStudiengang = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.CmdÄnderungSpeichernAuslandssemester = new System.Windows.Forms.Button();
            this.CmdPartnerhochschuldatensatzAuswählen = new System.Windows.Forms.Button();
            this.CmdPartnerhochschuldatenSuchen = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.ComboBoxPartnerhochschuleTblAuslandssemester = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.LblHochschule = new System.Windows.Forms.Label();
            this.TxtBoxKontaktperson = new System.Windows.Forms.TextBox();
            this.TxtBoxLand = new System.Windows.Forms.TextBox();
            this.TxtBoxOrt = new System.Windows.Forms.TextBox();
            this.GroupBoxStudentendatensatzAussuchen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.GroupBoxStudentendatensatzAuswählen.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // CmdStudentenSuchenTabelleStudenten
            // 
            this.CmdStudentenSuchenTabelleStudenten.Location = new System.Drawing.Point(6, 135);
            this.CmdStudentenSuchenTabelleStudenten.Name = "CmdStudentenSuchenTabelleStudenten";
            this.CmdStudentenSuchenTabelleStudenten.Size = new System.Drawing.Size(212, 23);
            this.CmdStudentenSuchenTabelleStudenten.TabIndex = 6;
            this.CmdStudentenSuchenTabelleStudenten.Text = "Studentendaten suchen";
            this.CmdStudentenSuchenTabelleStudenten.UseVisualStyleBackColor = true;
            this.CmdStudentenSuchenTabelleStudenten.Click += new System.EventHandler(this.CmdStudentenSuchenTabelleStudenten_Click);
            // 
            // GroupBoxStudentendatensatzAussuchen
            // 
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.LblMatrikelNr);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxMatrikelNr);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.ComboBoxPartnerhochschule);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.ComboBoxStudiengang);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label17);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxStudententyp);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label16);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxStudienende);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label15);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxStudienbeginn);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.Semester);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxSemester);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label14);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label13);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label12);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label11);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label10);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label9);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxEmail);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxTelefon);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxWohnort);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label8);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label7);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxPLZ);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxHausnummer);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label6);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label5);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label4);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label3);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label2);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.label1);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxStrasse);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxNationalität);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxGeburtsort);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxGeburtsdatum);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxVorname);
            this.GroupBoxStudentendatensatzAussuchen.Controls.Add(this.TxtBoxNachname);
            this.GroupBoxStudentendatensatzAussuchen.Location = new System.Drawing.Point(6, 6);
            this.GroupBoxStudentendatensatzAussuchen.Name = "GroupBoxStudentendatensatzAussuchen";
            this.GroupBoxStudentendatensatzAussuchen.Size = new System.Drawing.Size(1980, 123);
            this.GroupBoxStudentendatensatzAussuchen.TabIndex = 5;
            this.GroupBoxStudentendatensatzAussuchen.TabStop = false;
            this.GroupBoxStudentendatensatzAussuchen.Text = "zu ändernde Studentendaten suchen";
            // 
            // LblMatrikelNr
            // 
            this.LblMatrikelNr.AutoSize = true;
            this.LblMatrikelNr.Location = new System.Drawing.Point(16, 56);
            this.LblMatrikelNr.Name = "LblMatrikelNr";
            this.LblMatrikelNr.Size = new System.Drawing.Size(81, 13);
            this.LblMatrikelNr.TabIndex = 54;
            this.LblMatrikelNr.Text = "Matrikelnummer";
            // 
            // TxtBoxMatrikelNr
            // 
            this.TxtBoxMatrikelNr.Location = new System.Drawing.Point(6, 72);
            this.TxtBoxMatrikelNr.Name = "TxtBoxMatrikelNr";
            this.TxtBoxMatrikelNr.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxMatrikelNr.TabIndex = 53;
            // 
            // ComboBoxPartnerhochschule
            // 
            this.ComboBoxPartnerhochschule.FormattingEnabled = true;
            this.ComboBoxPartnerhochschule.Location = new System.Drawing.Point(875, 71);
            this.ComboBoxPartnerhochschule.Name = "ComboBoxPartnerhochschule";
            this.ComboBoxPartnerhochschule.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxPartnerhochschule.TabIndex = 52;
            // 
            // ComboBoxStudiengang
            // 
            this.ComboBoxStudiengang.FormattingEnabled = true;
            this.ComboBoxStudiengang.Location = new System.Drawing.Point(324, 72);
            this.ComboBoxStudiengang.Name = "ComboBoxStudiengang";
            this.ComboBoxStudiengang.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxStudiengang.TabIndex = 51;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(785, 56);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(70, 13);
            this.label17.TabIndex = 50;
            this.label17.Text = "Studententyp";
            // 
            // TxtBoxStudententyp
            // 
            this.TxtBoxStudententyp.Location = new System.Drawing.Point(769, 72);
            this.TxtBoxStudententyp.Name = "TxtBoxStudententyp";
            this.TxtBoxStudententyp.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudententyp.TabIndex = 49;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(680, 56);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 13);
            this.label16.TabIndex = 48;
            this.label16.Text = "Studienende";
            // 
            // TxtBoxStudienende
            // 
            this.TxtBoxStudienende.Location = new System.Drawing.Point(663, 72);
            this.TxtBoxStudienende.Name = "TxtBoxStudienende";
            this.TxtBoxStudienende.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudienende.TabIndex = 47;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(569, 56);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(75, 13);
            this.label15.TabIndex = 46;
            this.label15.Text = "Studienbeginn";
            // 
            // TxtBoxStudienbeginn
            // 
            this.TxtBoxStudienbeginn.Location = new System.Drawing.Point(557, 72);
            this.TxtBoxStudienbeginn.Name = "TxtBoxStudienbeginn";
            this.TxtBoxStudienbeginn.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudienbeginn.TabIndex = 45;
            // 
            // Semester
            // 
            this.Semester.AutoSize = true;
            this.Semester.Location = new System.Drawing.Point(478, 56);
            this.Semester.Name = "Semester";
            this.Semester.Size = new System.Drawing.Size(51, 13);
            this.Semester.TabIndex = 44;
            this.Semester.Text = "Semester";
            // 
            // TxtBoxSemester
            // 
            this.TxtBoxSemester.Location = new System.Drawing.Point(451, 72);
            this.TxtBoxSemester.Name = "TxtBoxSemester";
            this.TxtBoxSemester.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxSemester.TabIndex = 43;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(909, 56);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 13);
            this.label14.TabIndex = 29;
            this.label14.Text = "Ausland";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(883, 39);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(99, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Partnerhochschule ";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(351, 56);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 13);
            this.label12.TabIndex = 22;
            this.label12.Text = "Studiengang";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(1878, 55);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(36, 13);
            this.label11.TabIndex = 21;
            this.label11.Text = "E-Mail";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1771, 55);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Telefon";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(1664, 55);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 13);
            this.label9.TabIndex = 19;
            this.label9.Text = "Wohnort";
            // 
            // TxtBoxEmail
            // 
            this.TxtBoxEmail.Location = new System.Drawing.Point(1850, 71);
            this.TxtBoxEmail.Name = "TxtBoxEmail";
            this.TxtBoxEmail.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxEmail.TabIndex = 18;
            // 
            // TxtBoxTelefon
            // 
            this.TxtBoxTelefon.Location = new System.Drawing.Point(1744, 71);
            this.TxtBoxTelefon.Name = "TxtBoxTelefon";
            this.TxtBoxTelefon.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxTelefon.TabIndex = 17;
            // 
            // TxtBoxWohnort
            // 
            this.TxtBoxWohnort.Location = new System.Drawing.Point(1638, 71);
            this.TxtBoxWohnort.Name = "TxtBoxWohnort";
            this.TxtBoxWohnort.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxWohnort.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(1568, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(27, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "PLZ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(1442, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Hausnummer";
            // 
            // TxtBoxPLZ
            // 
            this.TxtBoxPLZ.Location = new System.Drawing.Point(1532, 71);
            this.TxtBoxPLZ.Name = "TxtBoxPLZ";
            this.TxtBoxPLZ.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxPLZ.TabIndex = 13;
            // 
            // TxtBoxHausnummer
            // 
            this.TxtBoxHausnummer.Location = new System.Drawing.Point(1426, 71);
            this.TxtBoxHausnummer.Name = "TxtBoxHausnummer";
            this.TxtBoxHausnummer.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxHausnummer.TabIndex = 12;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1343, 55);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Strasse";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1236, 55);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(60, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nationalität";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(1132, 55);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "Geburtsort";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1017, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Geburtsdatum";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(243, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Vorname";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(129, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Nachname";
            // 
            // TxtBoxStrasse
            // 
            this.TxtBoxStrasse.Location = new System.Drawing.Point(1320, 71);
            this.TxtBoxStrasse.Name = "TxtBoxStrasse";
            this.TxtBoxStrasse.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStrasse.TabIndex = 5;
            // 
            // TxtBoxNationalität
            // 
            this.TxtBoxNationalität.Location = new System.Drawing.Point(1214, 71);
            this.TxtBoxNationalität.Name = "TxtBoxNationalität";
            this.TxtBoxNationalität.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxNationalität.TabIndex = 4;
            // 
            // TxtBoxGeburtsort
            // 
            this.TxtBoxGeburtsort.Location = new System.Drawing.Point(1108, 71);
            this.TxtBoxGeburtsort.Name = "TxtBoxGeburtsort";
            this.TxtBoxGeburtsort.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxGeburtsort.TabIndex = 3;
            // 
            // TxtBoxGeburtsdatum
            // 
            this.TxtBoxGeburtsdatum.Location = new System.Drawing.Point(1002, 71);
            this.TxtBoxGeburtsdatum.Name = "TxtBoxGeburtsdatum";
            this.TxtBoxGeburtsdatum.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxGeburtsdatum.TabIndex = 2;
            // 
            // TxtBoxVorname
            // 
            this.TxtBoxVorname.Location = new System.Drawing.Point(218, 72);
            this.TxtBoxVorname.Name = "TxtBoxVorname";
            this.TxtBoxVorname.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxVorname.TabIndex = 1;
            // 
            // TxtBoxNachname
            // 
            this.TxtBoxNachname.Location = new System.Drawing.Point(112, 72);
            this.TxtBoxNachname.Name = "TxtBoxNachname";
            this.TxtBoxNachname.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxNachname.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(6, 30);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1873, 286);
            this.dataGridView1.TabIndex = 7;
            // 
            // CmdStudentenLöschen
            // 
            this.CmdStudentenLöschen.Location = new System.Drawing.Point(224, 135);
            this.CmdStudentenLöschen.Name = "CmdStudentenLöschen";
            this.CmdStudentenLöschen.Size = new System.Drawing.Size(212, 23);
            this.CmdStudentenLöschen.TabIndex = 8;
            this.CmdStudentenLöschen.Text = "Studentendatensatz auswählen";
            this.CmdStudentenLöschen.UseVisualStyleBackColor = true;
            this.CmdStudentenLöschen.Visible = false;
            this.CmdStudentenLöschen.Click += new System.EventHandler(this.CmdStudentenLöschen_Click);
            // 
            // GroupBoxStudentendatensatzAuswählen
            // 
            this.GroupBoxStudentendatensatzAuswählen.Controls.Add(this.dataGridView1);
            this.GroupBoxStudentendatensatzAuswählen.Location = new System.Drawing.Point(5, 293);
            this.GroupBoxStudentendatensatzAuswählen.Name = "GroupBoxStudentendatensatzAuswählen";
            this.GroupBoxStudentendatensatzAuswählen.Size = new System.Drawing.Size(1885, 342);
            this.GroupBoxStudentendatensatzAuswählen.TabIndex = 9;
            this.GroupBoxStudentendatensatzAuswählen.TabStop = false;
            this.GroupBoxStudentendatensatzAuswählen.Text = "Datensatz zum Ändern auswählen";
            this.GroupBoxStudentendatensatzAuswählen.Visible = false;
            // 
            // CmdÄnderungSpeichern
            // 
            this.CmdÄnderungSpeichern.Location = new System.Drawing.Point(442, 135);
            this.CmdÄnderungSpeichern.Name = "CmdÄnderungSpeichern";
            this.CmdÄnderungSpeichern.Size = new System.Drawing.Size(212, 23);
            this.CmdÄnderungSpeichern.TabIndex = 10;
            this.CmdÄnderungSpeichern.Text = "Änderung speichern";
            this.CmdÄnderungSpeichern.UseVisualStyleBackColor = true;
            this.CmdÄnderungSpeichern.Visible = false;
            this.CmdÄnderungSpeichern.Click += new System.EventHandler(this.CmdÄnderungSpeichern_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(5, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(2000, 198);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.CmdÄnderungSpeichern);
            this.tabPage1.Controls.Add(this.GroupBoxStudentendatensatzAussuchen);
            this.tabPage1.Controls.Add(this.CmdStudentenLöschen);
            this.tabPage1.Controls.Add(this.CmdStudentenSuchenTabelleStudenten);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1992, 172);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tabelle Studenten";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.CmdStudentendatensatzAuswählen);
            this.tabPage2.Controls.Add(this.CmdÄnderungSpeichernStudiengang);
            this.tabPage2.Controls.Add(this.CmdStudiengangsdatenSuchen);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1992, 172);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Tabelle Studiengang";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // CmdStudentendatensatzAuswählen
            // 
            this.CmdStudentendatensatzAuswählen.Location = new System.Drawing.Point(227, 126);
            this.CmdStudentendatensatzAuswählen.Name = "CmdStudentendatensatzAuswählen";
            this.CmdStudentendatensatzAuswählen.Size = new System.Drawing.Size(189, 23);
            this.CmdStudentendatensatzAuswählen.TabIndex = 17;
            this.CmdStudentendatensatzAuswählen.Text = "Studiengangsdatensatz auswählen";
            this.CmdStudentendatensatzAuswählen.UseVisualStyleBackColor = true;
            this.CmdStudentendatensatzAuswählen.Visible = false;
            this.CmdStudentendatensatzAuswählen.Click += new System.EventHandler(this.CmdStudentendatensatzAuswählen_Click);
            // 
            // CmdÄnderungSpeichernStudiengang
            // 
            this.CmdÄnderungSpeichernStudiengang.Location = new System.Drawing.Point(422, 126);
            this.CmdÄnderungSpeichernStudiengang.Name = "CmdÄnderungSpeichernStudiengang";
            this.CmdÄnderungSpeichernStudiengang.Size = new System.Drawing.Size(212, 23);
            this.CmdÄnderungSpeichernStudiengang.TabIndex = 16;
            this.CmdÄnderungSpeichernStudiengang.Text = "Änderung speichern";
            this.CmdÄnderungSpeichernStudiengang.UseVisualStyleBackColor = true;
            this.CmdÄnderungSpeichernStudiengang.Visible = false;
            this.CmdÄnderungSpeichernStudiengang.Click += new System.EventHandler(this.CmdÄnderungSpeichernStudiengang_Click);
            // 
            // CmdStudiengangsdatenSuchen
            // 
            this.CmdStudiengangsdatenSuchen.Location = new System.Drawing.Point(6, 126);
            this.CmdStudiengangsdatenSuchen.Name = "CmdStudiengangsdatenSuchen";
            this.CmdStudiengangsdatenSuchen.Size = new System.Drawing.Size(212, 23);
            this.CmdStudiengangsdatenSuchen.TabIndex = 15;
            this.CmdStudiengangsdatenSuchen.Text = "Studiengangsdaten suchen";
            this.CmdStudiengangsdatenSuchen.UseVisualStyleBackColor = true;
            this.CmdStudiengangsdatenSuchen.Click += new System.EventHandler(this.CmdStudiengangsdatenSuchen_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.ComboBoxStudiengangTblStudiengang);
            this.groupBox3.Controls.Add(this.label27);
            this.groupBox3.Controls.Add(this.label26);
            this.groupBox3.Controls.Add(this.TxtBoxEmailStudiengangsleitung);
            this.groupBox3.Controls.Add(this.TxtBoxTelefonStudiengangsleitung);
            this.groupBox3.Controls.Add(this.TxtBoxStudiengangsleiter);
            this.groupBox3.Controls.Add(this.label25);
            this.groupBox3.Controls.Add(this.label24);
            this.groupBox3.Controls.Add(this.label23);
            this.groupBox3.Controls.Add(this.LblStudiengang);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(664, 114);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "zu ändernde Studiengangsdaten suchen";
            // 
            // ComboBoxStudiengangTblStudiengang
            // 
            this.ComboBoxStudiengangTblStudiengang.FormattingEnabled = true;
            this.ComboBoxStudiengangTblStudiengang.Location = new System.Drawing.Point(6, 53);
            this.ComboBoxStudiengangTblStudiengang.Name = "ComboBoxStudiengangTblStudiengang";
            this.ComboBoxStudiengangTblStudiengang.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxStudiengangTblStudiengang.TabIndex = 10;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(342, 37);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 13);
            this.label27.TabIndex = 9;
            this.label27.Text = "Studiengangsleitung";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(239, 37);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(103, 13);
            this.label26.TabIndex = 8;
            this.label26.Text = "Studiengangsleitung";
            // 
            // TxtBoxEmailStudiengangsleitung
            // 
            this.TxtBoxEmailStudiengangsleitung.Location = new System.Drawing.Point(345, 53);
            this.TxtBoxEmailStudiengangsleitung.Name = "TxtBoxEmailStudiengangsleitung";
            this.TxtBoxEmailStudiengangsleitung.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxEmailStudiengangsleitung.TabIndex = 7;
            // 
            // TxtBoxTelefonStudiengangsleitung
            // 
            this.TxtBoxTelefonStudiengangsleitung.Location = new System.Drawing.Point(239, 53);
            this.TxtBoxTelefonStudiengangsleitung.Name = "TxtBoxTelefonStudiengangsleitung";
            this.TxtBoxTelefonStudiengangsleitung.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxTelefonStudiengangsleitung.TabIndex = 6;
            // 
            // TxtBoxStudiengangsleiter
            // 
            this.TxtBoxStudiengangsleiter.Location = new System.Drawing.Point(133, 53);
            this.TxtBoxStudiengangsleiter.Name = "TxtBoxStudiengangsleiter";
            this.TxtBoxStudiengangsleiter.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxStudiengangsleiter.TabIndex = 5;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(378, 24);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(32, 13);
            this.label25.TabIndex = 3;
            this.label25.Text = "Email";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(266, 24);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(43, 13);
            this.label24.TabIndex = 2;
            this.label24.Text = "Telefon";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(139, 37);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(94, 13);
            this.label23.TabIndex = 1;
            this.label23.Text = "Studiengangsleiter";
            // 
            // LblStudiengang
            // 
            this.LblStudiengang.AutoSize = true;
            this.LblStudiengang.Location = new System.Drawing.Point(24, 37);
            this.LblStudiengang.Name = "LblStudiengang";
            this.LblStudiengang.Size = new System.Drawing.Size(67, 13);
            this.LblStudiengang.TabIndex = 0;
            this.LblStudiengang.Text = "Studiengang";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.CmdÄnderungSpeichernAuslandssemester);
            this.tabPage3.Controls.Add(this.CmdPartnerhochschuldatensatzAuswählen);
            this.tabPage3.Controls.Add(this.CmdPartnerhochschuldatenSuchen);
            this.tabPage3.Controls.Add(this.groupBox2);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1992, 172);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Tabelle Auslandssemester";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // CmdÄnderungSpeichernAuslandssemester
            // 
            this.CmdÄnderungSpeichernAuslandssemester.Location = new System.Drawing.Point(360, 125);
            this.CmdÄnderungSpeichernAuslandssemester.Name = "CmdÄnderungSpeichernAuslandssemester";
            this.CmdÄnderungSpeichernAuslandssemester.Size = new System.Drawing.Size(157, 23);
            this.CmdÄnderungSpeichernAuslandssemester.TabIndex = 18;
            this.CmdÄnderungSpeichernAuslandssemester.Text = "Änderung speichern";
            this.CmdÄnderungSpeichernAuslandssemester.UseVisualStyleBackColor = true;
            this.CmdÄnderungSpeichernAuslandssemester.Visible = false;
            this.CmdÄnderungSpeichernAuslandssemester.Click += new System.EventHandler(this.CmdÄnderungSpeichernAuslandssemester_Click);
            // 
            // CmdPartnerhochschuldatensatzAuswählen
            // 
            this.CmdPartnerhochschuldatensatzAuswählen.Location = new System.Drawing.Point(184, 125);
            this.CmdPartnerhochschuldatensatzAuswählen.Name = "CmdPartnerhochschuldatensatzAuswählen";
            this.CmdPartnerhochschuldatensatzAuswählen.Size = new System.Drawing.Size(170, 23);
            this.CmdPartnerhochschuldatensatzAuswählen.TabIndex = 17;
            this.CmdPartnerhochschuldatensatzAuswählen.Text = "Hochschuldatensatz auswählen";
            this.CmdPartnerhochschuldatensatzAuswählen.UseVisualStyleBackColor = true;
            this.CmdPartnerhochschuldatensatzAuswählen.Visible = false;
            this.CmdPartnerhochschuldatensatzAuswählen.Click += new System.EventHandler(this.CmdPartnerhochschuldatensatzAuswählen_Click);
            // 
            // CmdPartnerhochschuldatenSuchen
            // 
            this.CmdPartnerhochschuldatenSuchen.Location = new System.Drawing.Point(6, 125);
            this.CmdPartnerhochschuldatenSuchen.Name = "CmdPartnerhochschuldatenSuchen";
            this.CmdPartnerhochschuldatenSuchen.Size = new System.Drawing.Size(172, 23);
            this.CmdPartnerhochschuldatenSuchen.TabIndex = 16;
            this.CmdPartnerhochschuldatenSuchen.Text = "Hochschuldaten suchen";
            this.CmdPartnerhochschuldatenSuchen.UseVisualStyleBackColor = true;
            this.CmdPartnerhochschuldatenSuchen.Click += new System.EventHandler(this.CmdPartnerhochschuldatenSuchen_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.ComboBoxPartnerhochschuleTblAuslandssemester);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.LblHochschule);
            this.groupBox2.Controls.Add(this.TxtBoxKontaktperson);
            this.groupBox2.Controls.Add(this.TxtBoxLand);
            this.groupBox2.Controls.Add(this.TxtBoxOrt);
            this.groupBox2.Location = new System.Drawing.Point(6, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(461, 103);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "zu ändernde Partnerhochschuldaten suchen";
            // 
            // ComboBoxPartnerhochschuleTblAuslandssemester
            // 
            this.ComboBoxPartnerhochschuleTblAuslandssemester.FormattingEnabled = true;
            this.ComboBoxPartnerhochschuleTblAuslandssemester.Location = new System.Drawing.Point(6, 43);
            this.ComboBoxPartnerhochschuleTblAuslandssemester.Name = "ComboBoxPartnerhochschuleTblAuslandssemester";
            this.ComboBoxPartnerhochschuleTblAuslandssemester.Size = new System.Drawing.Size(121, 21);
            this.ComboBoxPartnerhochschuleTblAuslandssemester.TabIndex = 19;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(356, 28);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(76, 13);
            this.label18.TabIndex = 9;
            this.label18.Text = "Kontaktperson";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(270, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(31, 13);
            this.label19.TabIndex = 7;
            this.label19.Text = "Land";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(168, 28);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(21, 13);
            this.label20.TabIndex = 5;
            this.label20.Text = "Ort";
            // 
            // LblHochschule
            // 
            this.LblHochschule.AutoSize = true;
            this.LblHochschule.Location = new System.Drawing.Point(28, 27);
            this.LblHochschule.Name = "LblHochschule";
            this.LblHochschule.Size = new System.Drawing.Size(64, 13);
            this.LblHochschule.TabIndex = 4;
            this.LblHochschule.Text = "Hochschule";
            // 
            // TxtBoxKontaktperson
            // 
            this.TxtBoxKontaktperson.Location = new System.Drawing.Point(345, 44);
            this.TxtBoxKontaktperson.Name = "TxtBoxKontaktperson";
            this.TxtBoxKontaktperson.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxKontaktperson.TabIndex = 3;
            // 
            // TxtBoxLand
            // 
            this.TxtBoxLand.Location = new System.Drawing.Point(239, 44);
            this.TxtBoxLand.Name = "TxtBoxLand";
            this.TxtBoxLand.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxLand.TabIndex = 2;
            // 
            // TxtBoxOrt
            // 
            this.TxtBoxOrt.Location = new System.Drawing.Point(133, 44);
            this.TxtBoxOrt.Name = "TxtBoxOrt";
            this.TxtBoxOrt.Size = new System.Drawing.Size(100, 20);
            this.TxtBoxOrt.TabIndex = 1;
            // 
            // StudentenÄndern
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2008, 676);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.GroupBoxStudentendatensatzAuswählen);
            this.Name = "StudentenÄndern";
            this.Text = "Studentendaten ändern";
            this.GroupBoxStudentendatensatzAussuchen.ResumeLayout(false);
            this.GroupBoxStudentendatensatzAussuchen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.GroupBoxStudentendatensatzAuswählen.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CmdStudentenSuchenTabelleStudenten;
        private System.Windows.Forms.GroupBox GroupBoxStudentendatensatzAussuchen;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TxtBoxEmail;
        private System.Windows.Forms.TextBox TxtBoxTelefon;
        private System.Windows.Forms.TextBox TxtBoxWohnort;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TxtBoxPLZ;
        private System.Windows.Forms.TextBox TxtBoxHausnummer;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TxtBoxStrasse;
        private System.Windows.Forms.TextBox TxtBoxNationalität;
        private System.Windows.Forms.TextBox TxtBoxGeburtsort;
        private System.Windows.Forms.TextBox TxtBoxGeburtsdatum;
        private System.Windows.Forms.TextBox TxtBoxVorname;
        public System.Windows.Forms.TextBox TxtBoxNachname;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button CmdStudentenLöschen;
        private System.Windows.Forms.GroupBox GroupBoxStudentendatensatzAuswählen;
        private System.Windows.Forms.Button CmdÄnderungSpeichern;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox TxtBoxStudententyp;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox TxtBoxStudienende;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox TxtBoxStudienbeginn;
        private System.Windows.Forms.Label Semester;
        private System.Windows.Forms.TextBox TxtBoxSemester;
        private System.Windows.Forms.ComboBox ComboBoxPartnerhochschule;
        private System.Windows.Forms.ComboBox ComboBoxStudiengang;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox TxtBoxEmailStudiengangsleitung;
        private System.Windows.Forms.TextBox TxtBoxTelefonStudiengangsleitung;
        private System.Windows.Forms.TextBox TxtBoxStudiengangsleiter;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label LblStudiengang;
        private System.Windows.Forms.Button CmdÄnderungSpeichernStudiengang;
        private System.Windows.Forms.Button CmdStudiengangsdatenSuchen;
        private System.Windows.Forms.Button CmdStudentendatensatzAuswählen;
        private System.Windows.Forms.Button CmdÄnderungSpeichernAuslandssemester;
        private System.Windows.Forms.Button CmdPartnerhochschuldatensatzAuswählen;
        private System.Windows.Forms.Button CmdPartnerhochschuldatenSuchen;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label LblHochschule;
        private System.Windows.Forms.TextBox TxtBoxKontaktperson;
        private System.Windows.Forms.TextBox TxtBoxLand;
        private System.Windows.Forms.TextBox TxtBoxOrt;
        private System.Windows.Forms.ComboBox ComboBoxPartnerhochschuleTblAuslandssemester;
        private System.Windows.Forms.ComboBox ComboBoxStudiengangTblStudiengang;
        private System.Windows.Forms.Label LblMatrikelNr;
        private System.Windows.Forms.TextBox TxtBoxMatrikelNr;
    }
}