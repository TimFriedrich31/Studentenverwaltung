﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Studentenverwaltung
{

    public partial class StudentenAnlegen : Form
    {
        public StudentenAnlegen()
        {
            InitializeComponent();
            FillComboBoxPartnerhochschule();
            FillComboBoxStudiengang();
           

            // Um zu vermeiden, dass der Benutzer die Comboboxen leer lässt, welche aber Primärschlüssel in der Datenbank sind und immer benötigt werden, wird ihnen hier vorab ein Wert zugewiesen, der dann 
            // verändert werden kann. Und falls er die Combobox durch löschen des Inhalts dennoch leer lässt, so wird diese Exception aufgefangen und der Benutzer wird gebeten die Felder zu füllen.
            ComboBoxPartnerhochschule.Text = "keine";
            ComboBoxStudiengang.Text = "WIW-ITP";

        }

        //Combobox der Partnerhochschule mit den Werten aus der Datenbank füllen
        void FillComboBoxPartnerhochschule()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Hochschule from studentendaten.auslandssemester";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);        
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Hochschule = myReader.GetString("Hochschule");
                    ComboBoxPartnerhochschule.Items.Add(Hochschule);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex) 
            {
                MessageBox.Show(ex.Message);          
            }
        }
       
        //Combobox des Studiengangs mit den Werten aus der Datenbank füllen
        void FillComboBoxStudiengang()
        {
            string constring = "datasource=localhost;port=3306;username=root;password=";
            string Query = "select Studiengang from studentendaten.studiengang";
            MySqlConnection conDataBase = new MySqlConnection(constring);
            MySqlCommand cmdDataBase = new MySqlCommand(Query, conDataBase);
            MySqlDataReader myReader;

            try
            {
                conDataBase.Open();
                myReader = cmdDataBase.ExecuteReader();

                while (myReader.Read())
                {
                    string Studiengang = myReader.GetString("Studiengang");
                    ComboBoxStudiengang.Items.Add(Studiengang);
                }
                conDataBase.Close();
                myReader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //Studenten-Tabelle:

        //Die in die Textboxen eingegebenen Werte in der Datenbank speichern, zusätzlich soll das Semester anhand der bereits absolvierten Tage an der Hochschule bestimmt werden
        private MySqlCommand command = null;
        private MySqlDataReader reader = null;
  
        
        private void CmdStudentenAnlegen_Click(object sender, EventArgs e)
        {   string Nachname = TxtBoxNachname.Text;
            string Vorname = TxtBoxVorname.Text;
            string Studiengang = ComboBoxStudiengang.Text;
        //  string Semester wird weiter unten bestimmt 
            string Studienbeginn = DateTimePickerStudienbeginn.Value.ToString("yyyy-MM-dd");
            string Studienende = DateTimePickerStudienende.Value.ToString("yyyy-MM-dd");
            string Studententyp = TxtBoxStudententyp.Text;
            string Partnerhochschule = ComboBoxPartnerhochschule.Text;
            string Geburtsdatum = TxtBoxGeburtsdatum.Text;
            string Geburtsort = TxtBoxGeburtsort.Text;
            string Nationalität = TxtBoxNationalität.Text;
            string Strasse = TxtBoxStrasse.Text;
            string Hausnummer = TxtBoxHausnummer.Text;
            string PLZ = TxtBoxPLZ.Text;
            string Wohnort = TxtBoxWohnort.Text;
            string Telefon = TxtBoxTelefon.Text;
            string Email = TxtBoxEmail.Text;

            //Bestimmung wieviele Tage seit Studienbeginn vergangen sind            
            DateTime DatumStudienbeginn = System.Convert.ToDateTime(DateTimePickerStudienbeginn.Value.ToString("yyyy-MM-dd"));
            TimeSpan SpanneSeitStudienbeginn = DateTime.Now - DatumStudienbeginn;
            textBox1.Text = SpanneSeitStudienbeginn.Days.ToString();
            double AnzahlTage = Convert.ToDouble(textBox1.Text);

            //Bestimmung wieviele Tage Zwischen Studienbeginn und Studienende liegen
            DateTime DatumStudienende = System.Convert.ToDateTime(DateTimePickerStudienende.Value.ToString("yyyy-MM-dd"));
         
            //Nur wenn der Studienbeginn nicht in der Zukunft liegt kann auch ein Semester bestimmt werden 
            int result1 = DateTime.Compare(DatumStudienbeginn, DateTime.Now);
            if (result1 < 0 || result1 == 0) //Bedeutet, dass das DAtum des Studienbeginns kleiner ist als das aktuelle
            {

                //Nur wenn der Studienbeginn vom Datum her vor dem Studienende liegt, soll es auch angelegt werden können
                int result = DateTime.Compare(DatumStudienbeginn, DatumStudienende);
                if (result < 0) //Bedeutet, dass Studienbeginn vom Datum her vor dem Studienende liegt
                {

                    //Anlegen von Semester 1, wenn weniger als 182 Tage(halbes Jahr = 1 Semester) seit Studienbeginn vergangen sind
                    if (AnzahlTage < 182 && AnzahlTage > 0)
                    {
                        string Semester = "1";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "1";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 2, wenn mehr als 182 Tage(halbes Jahr) und weniger als 365 Tage(ein Jahr) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 182 && AnzahlTage < 365)
                    {
                        string Semester = "2";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "2";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 3, wenn mehr als 365 Tage(ein Jahr) und weniger als 547 Tage(eineinhalb Jahre) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 365 && AnzahlTage < 547)
                    {
                        string Semester = "3";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "3";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 4, wenn mehr als 547 Tage(eineinhalb Jahre) und weniger als 730 Tage(zwei Jahre) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 547 && AnzahlTage < 730)
                    {
                        string Semester = "4";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "4";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 5, wenn mehr als 730 Tage(zwei Jahre) und weniger als 912 Tage(zweieinhalb Jahre) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 730 && AnzahlTage < 912)
                    {
                        string Semester = "5";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "5";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 6, wenn mehr als 912 Tage(zweieinhalb Jahre) und weniger als 1095 Tage(drei Jahre) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 912 && AnzahlTage < 1095)
                    {
                        string Semester = "6";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "6";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 7, wenn mehr als 1095 Tage(drei Jahre) und weniger als 1277 Tage(dreieinhalb Jahre) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 1095 && AnzahlTage < 1277)
                    {
                        string Semester = "7";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "7";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 8, wenn mehr als 1277 Tage(dreieinhalb Jahre) und weniger als 1460 Tage(vier Jahre) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 1277 && AnzahlTage < 1460)
                    {
                        string Semester = "8";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "8";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 9, wenn mehr als 1460 Tage(vier Jahre) und weniger als 1642 Tage(viereinhalb Jahre) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 1460 && AnzahlTage < 1642)
                    {
                        string Semester = "9";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "9";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }

                    //Anlegen von Semester 10, wenn mehr als 1642 Tage(viereinhalb Jahre) und weniger als 1900 Tage(etwa fünf Jahre) seit Studienbeginn vergangen sind
                    if (AnzahlTage > 1642 && AnzahlTage < 1900)
                    {
                        string Semester = "10";

                        string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                        MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                        try
                        {
                            if (ComboBoxStudiengang.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else if (ComboBoxPartnerhochschule.Text == "")
                            {
                                MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                            }
                            else
                            {
                                connection.Open();
                                command = new MySqlCommand(Anlegen);
                                command.Connection = connection;
                                reader = command.ExecuteReader();
                                LblSemester.Text = "10";
                                LblSemester.Visible = true;

                                reader.Close();

                                connection.Close();
                                MessageBox.Show("Student wurde erfolgreich angelegt");
                                LblSemester.Visible = false;
                            }

                        }
                        catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
                else if (result == 0) //Bedeutet, dass Studienbeginn und Studienende dasselbe Datum haben 
                {
                    MessageBox.Show("Studienbeginn und Studienende haben dasselbe Datum, bitte korrigieren");
                }
                else //Bedeutet, dass der Studienbeginn vom Datum her hinter dem Studienende liegt, was ja falsch wäre
                {
                    MessageBox.Show("Der Studienbeginn hat ein späteres Datum als das Studienende, bitte korrigieren");
                }
            }
            else //Hier liegt der Studienbeginn noch in der Zukunft
            {
                string Semester = "0";

                string Anlegen = "insert into studenten (Nachname, Vorname, Studiengang, Semester, Studienbeginn, Studienende, Studententyp, Partnerhochschule_Ausland, Geburtsdatum, Geburtsort, Nationalität, Strasse, Hausnummer, PLZ, Wohnort, Telefon, Email) values ('" + Nachname + "','" + Vorname + "','" + Studiengang + "','" + Semester + "','" + Studienbeginn + "','" + Studienende + "','" + Studententyp + "','" + Partnerhochschule + "','" + Geburtsdatum + "','" + Geburtsort + "','" + Nationalität + "','" + Strasse + "','" + Hausnummer + "','" + PLZ + "','" + Wohnort + "','" + Telefon + "','" + Email + "')";

                MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

                try
                {
                    if (ComboBoxStudiengang.Text == "")
                    {
                        MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                    }
                    else if (ComboBoxPartnerhochschule.Text == "")
                    {
                        MessageBox.Show("Bitte lassen Sie das Studiengangs- oder Partnerhochschulfeld nicht leer");
                    }
                    else
                    {
                        connection.Open();
                        command = new MySqlCommand(Anlegen);
                        command.Connection = connection;
                        reader = command.ExecuteReader();
                        LblSemester.Text = "10";
                        LblSemester.Visible = true;

                        reader.Close();

                        connection.Close();
                        MessageBox.Show("Student wurde erfolgreich angelegt");
                        LblSemester.Visible = false;
                    }

                }
                catch (Exception ex)//Falls die Comboboxen leer sind wird der Benutzer gebeten diese nicht leer zu lassen
                {
                    MessageBox.Show(ex.Message);
                }
            }
          
           //Wenn das Datum des Studienbeginns falsch eingetippt wurde, bzw. mehr als 1900 Tage(etwa fünf Jahre und somit abgeschlossener Master) seit Studienbeginn vergangen sind, den Benutzer darauf hinweisen
    //        if (AnzahlTage > 1900)
      //      {
     //           MessageBox.Show("Bitte achten Sie auf ein korrektes Datum");
       //     }

            //Wenn Studienbeginn und Studienende das selbe Datum haben, den Benutzer darauf hinweisen
 //           if (DatumStudienende == DatumStudienbeginn)
   //         {
     //           MessageBox.Show("Ihr Studienbeginn und Studienende haben das gleiche Datum");
       //     }
        } 
           
        

        //Studiengangs-Tabelle:
        private void CmdStudentenAnlegenTblStudiengang_Click(object sender, EventArgs e)
        {
            string StudiengangTblStudiengang = TxtBoxStudiengangTblStudiengang.Text;
            string Studiengangsleiter = TxtBoxStudiengangsleiter.Text;
            string TelefonStudiengangsleitung = TxtBoxTelefonStudiengangsleitung.Text;
            string EmailStudiengangsleitung = TxtBoxEmailStudiengangsleitung.Text;

            string Anlegen = "insert into studiengang (Studiengang, Studiengangsleiter, Telefon_Studiengangsleitung, Email_Studiengangsleitung) values ('" + StudiengangTblStudiengang + "','" + Studiengangsleiter + "','" + TelefonStudiengangsleitung + "','" + EmailStudiengangsleitung + "')";

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

            try
            {
                if (TxtBoxStudiengangTblStudiengang.Text == "")
                {
                    MessageBox.Show("Bitte lassen Sie das Studiengangsfeld nicht leer");
                }
                else
                {
                    connection.Open();
                    command = new MySqlCommand(Anlegen);
                    command.Connection = connection;
                    reader = command.ExecuteReader();

                    reader.Close();

                    connection.Close();
                    MessageBox.Show("Studiengang wurde erfolgreich angelegt");
                }
            }
            catch(Exception ex) //Falls die Textbox für den Studiengang leer ist wird der Benutzer gebeten diese nicht leer zu lassen
            {
                MessageBox.Show(ex.Message);               
            }
        }

        

        //Auslandssemester-Tabelle:
        private void CmdPartnerhochschuleAnlegen_Click(object sender, EventArgs e)
        {
            string PartnerhochschuleTblAuslandssemester = TxtBoxPartnerhochschuleTblAuslandssemester.Text;
            string Ort = TxtBoxOrt.Text;
            string Land = TxtBoxLand.Text;
            string Kontaktperson = TxtBoxKontaktperson.Text;

            string Anlegen = "insert into auslandssemester (Hochschule, Ort, Land, Kontaktperson) values ('" + PartnerhochschuleTblAuslandssemester + "','" + Ort + "','" + Land + "','" + Kontaktperson + "')";

            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");

            try
            {
                if (TxtBoxPartnerhochschuleTblAuslandssemester.Text == "")
                {
                    MessageBox.Show("Bitte lassen Sie das Hochschulfeld nicht leer");
                }
                else
                {
                connection.Open();
                command = new MySqlCommand(Anlegen);
                command.Connection = connection;
                reader = command.ExecuteReader();

                reader.Close();

                connection.Close();
                MessageBox.Show("Partnerhochschule wurde erfolgreich angelegt");
                }               
            }
            catch(Exception ex) //Falls die Textbox für die Hochschule leer ist wird der Benutzer gebeten diese nicht leer zu lassen
            {
                MessageBox.Show(ex.Message);
            }
        }









    }
}
