﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;



namespace Studentenverwaltung
{
    public partial class Studentenverwaltung : Form
    {
     
        public Studentenverwaltung()
        {
            InitializeComponent();


// Verbindung zur Studenten-Datenbank herstellen, Verbindungsstatus anzeigen und Exception-Handling
            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
            try
            {
                connection.Open();
                LblVerbunden.Visible = true;
            }
            catch(Exception ex)
            {
                LblGetrennt.Text = ex.Message;
                LblGetrennt.Visible = true;
            }

           
        }


// Verbindung schließen, GUI beenden und Exception-Handling
        private void CmdBeenden_Click(object sender, EventArgs e)
        {            
            MySqlConnection connection = new MySqlConnection("server=localhost; database=studentendaten; uid=root; password=");
            try
            {
                connection.Close();                               
                System.Environment.Exit(0);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }                      
        }

    
// Form "Anlegen" öffnen und Daten aus Form Anlegen an Form Studentenverwaltung übergeben
        private void CmdAnlegen_Click(object sender, EventArgs e)
        {
            StudentenAnlegen AnlegenForm = new StudentenAnlegen();
            AnlegenForm.Show();
        }

        private void CmdStudentenAnlegen_Click(object sender, EventArgs e)
        {
            
        }

        private void CmdSuchen_Click(object sender, EventArgs e)
        {
            StudentenSuchen SuchenForm = new StudentenSuchen();
            SuchenForm.Show();
        }

        private void CmdLöschen_Click(object sender, EventArgs e)
        {
            StudentenLöschen LöschenForm = new StudentenLöschen();
            LöschenForm.Show();
        }

        private void CmdÄndern_Click(object sender, EventArgs e)
        {
            StudentendatenÄndern ÄndernForm = new StudentendatenÄndern();
            ÄndernForm.Show();
        }
    }

}
